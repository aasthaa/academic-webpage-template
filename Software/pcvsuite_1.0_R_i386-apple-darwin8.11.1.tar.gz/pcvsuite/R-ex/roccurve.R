### Name: roccurve
### Title: Estimate and plot ROC Curves
### Aliases: roccurve


### ** Examples

nnhs2 <- read.csv("http://labs.fhcrc.org/pepe/book/data/nnhs2.csv", 
                   header = TRUE, sep = ",")
## Three ways of producing the same plot
roccurve(dataset="nnhs2", d="d", markers="y1")    # Vectors part of a data frame
roccurve(d="nnhs2$d", markers="nnhs2$y1")

disease <- nnhs2$d
marker1 <- nnhs2$y1
roccurve(d="disease", markers="marker1")          # Independent vectors, not in a data frame

## Multiple markers
roccurve(d="nnhs2$d", markers=c("nnhs2$y1", "nnhs2$y2"))

## Sampling Variability
#roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), roc=0.10, nsamp=5000)
#roccurve(dataset="nnhs2", d="d", markers=c("y1","y2","y3"), roc=0.15, level=90)
# Get ROC(0.10), using cohort sampling and 5000 bootstrap samples
roccurve(dataset="nnhs2", d="d", markers="y1", roc=0.10, 
         noccsamp=TRUE, nsamp=5000)
# Get ROC(0.15), generating a 90
roccurve(d="nnhs2$d", markers=c("nnhs2$y1", "nnhs2$y2"), roc=0.15, level=90)
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2","y3"), roc=0.1, 
         level=95, cluster="id")

## Percentile value calculation method
# Using tie correction
roccurve(d="nnhs2$d", markers=c("nnhs2$y1", "nnhs2$y2"), tiecorr=TRUE)
# Assuming normal distribution
roccurve(d="nnhs2$d", markers=c("nnhs2$y1", "nnhs2$y2"), pvcmeth="normal")

## Parametric ROC curves
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), roc=0.2, 
         rocmeth="parametric")
roccurve(dataset="nnhs2", d="d", markers="y1", roc=0.2, rocmeth="parametric", 
         link="logit")
roccurve(dataset="nnhs2", d="d", markers="y1", roc=0.05, rocmeth="parametric", 
         interval=c(0, 0.1, 10))

## Get ROC Inverse, ROC^-1(0.8)
roccurve(dataset="nnhs2", d="d", markers="y1", rocinv=0.8)

## New variable options
# Generate pcv variable containing percentile values for marker y1
roccurve(dataset="nnhs2", d="d", markers="y1", roc=0.2, genpcv=TRUE)
# Try to store percentile values when pcv variable already exists
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), roc=0.2, genpcv=TRUE)
#Graph options - don't generate a plot
roccurve(dataset="nnhs2", d="d", markers=c("y1"), roc=0.2, nograph=TRUE)
## With Covariate Adjustment
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), 
         adjcov=c("currage","gender"))
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), 
         adjcov=c("currage","gender"), adjmodel="linear")
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov="currage", 
         adjmodel="linear", pvcmeth="normal", roc=0.20)
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov="currage",
         rocmeth="parametric")
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov="currage", 
         rocmeth="parametric", interval=c(0,0.2,5))
roccurve(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov="currage",  
         genrocvars=TRUE, genpcv=TRUE)



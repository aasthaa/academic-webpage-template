### Name: rocreg
### Title: Receiver Operating Characteristic (ROC) Regression
### Aliases: rocreg


### ** Examples

nnhs2 <- read.csv("http://labs.fhcrc.org/pepe/book/data/nnhs2.csv", 
                  header = TRUE, sep = ",")
rocreg(dataset="nnhs2", d="d", markers="y1", cluster="id", noccsamp=T)
rocreg(dataset="nnhs2", d="d", markers="y1", 
       adjcov="gender", regcov="gender", cluster="id", noccsamp=T, level=90)
rocreg(dataset="nnhs2", d="d", markers="y1", adjcov="gender",
       regcov="gender", pvcmeth="normal", cluster="id", noccsamp=T)
rocreg(dataset="nnhs2", d="d", markers=c("y1","y2"),
       adjcov=c("currage","gender"), adjmodel="linear", regcov="currage",
       cluster="id", noccsamp=T)
rocreg(dataset="nnhs2", d="d", markers="y1", 
       adjcov="gender", regcov="gender", sregcov="gender", link="logit", 
       cluster="id", noccsamp=T)




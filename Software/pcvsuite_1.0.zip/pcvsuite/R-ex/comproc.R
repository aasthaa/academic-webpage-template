### Name: comproc
### Title: Estimation and Comparison of Summary Statistics for the Receiver
###   Operating Characteristic Curve (ROC)
### Aliases: comproc


### ** Examples
             
nnhs2 <- read.csv("http://labs.fhcrc.org/pepe/book/data/nnhs2.csv", 
   header = TRUE, sep = ",")

comproc(dataset="nnhs2", d="d", markers=c("y1","y2"))
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), pauc=0.10)                                                     
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.10, level=90)
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.20, roc=0.20, 
   nsamp=5000)
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), pauc=0.20, 
   pvcmeth="normal", resfile="rfile1", replace=TRUE)
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), pvcmeth="normal", 
   noccsamp=TRUE, cluster="y1")
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), 
   adjcov=c("currage","gender"))
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov=c("currage","gender"), 
   adjmodel="linear")
comproc(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov="currage", 
   adjmodel="linear", pvcmeth="normal")




### Name: predcurve
### Title: Predictiveness Curve Estimation
### Aliases: predcurve


### ** Examples

janssens <- read.table("http://labs.fhcrc.org/pepe/data/janssens_c.csv",
                       sep=",",header=T)

predcurve(dataset="janssens",d="disease", markers="logscr")
 
predcurve(dataset="janssens",d="disease", markers=c("logscr","bmi"))

predcurve(dataset="janssens",d="disease", markers=c("logscr","bmi"),riskh=.4)

predcurve(dataset="janssens",d="disease", markers=c("logscr","bmi"),
          riskh=.4,riskl = .1, class=TRUE)

predcurve(dataset="janssens",d="disease", markers="logscr", 
   covar=c("age","hypertension","bmi","bruit","vascular","gender"), 
   link="logit", riskl=.1, riskh=.4, ci=TRUE, class=TRUE)

####### 
# example of nested marker models
m1 <- glm(disease ~ bmi +age +hypertension +bruit +vascular +gender,
          data=janssens, family=binomial)
janssens$m1Fit <- m1$linear.predictors  
m2 <- glm(disease ~ bmi +age +hypertension +bruit +vascular +gender +logscr,
          data=janssens, family=binomial)
janssens$m2Fit <- m2$linear.predictors  

predcurve(dataset="janssens", d="disease",markers=c("m1Fit","m2Fit"),
          riskh=.4,riskl = .1, class=TRUE, ci=TRUE)

####### 
# examples of alternate graphical outputs (cdf and density)
predcurve(dataset="janssens", d="disease",markers=c("m1Fit","m2Fit"),
          riskh=.4,riskl = .1, class=TRUE, plot_type="cdf",ci=TRUE)

predcurve(dataset="janssens", d="disease",markers=c("m1Fit","m2Fit"),
          riskh=.4,riskl = .1, class=TRUE, plot_type="density")

predcurve(dataset="janssens", d="disease",markers=c("m1Fit","m2Fit"),
          riskh=.4,riskl = .1, class=TRUE, plot_type="density",densBW=1)

####### 
# example using nested parameter (same as above except (1) no need for
#     fitting models outside of predcurve and (2) CI may differ 
#     since covariates are being included in the bootstrap)

predcurve(dataset="janssens",d="disease", markers="logscr", 
   covar=c("bmi","age","hypertension","bruit","vascular","gender"), 
   link="logit", riskl=.1, riskh=.4, class=TRUE, ci=TRUE, nested=TRUE)





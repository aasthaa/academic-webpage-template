setwd("C:\\Users\\Aasthaa\\Documents\\RA_Hutch\\2009_11_13_fromDaryl")
source("rocreg.R")
source("hidden.R")

### Documentation examples
nnhs2 <- read.csv("http://labs.fhcrc.org/pepe/book/data/nnhs2.csv",header = TRUE, sep = ",")

rocreg(dataset="nnhs2", d="d", markers="y1", cluster="id", noccsamp=T, nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers="y1", adjcov="gender", regcov="gender", cluster="id", noccsamp=T, level=90, nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers="y1", adjcov="gender", regcov="gender", pvcmeth="normal", cluster="id", noccsamp=T, nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1","y2"), adjcov=c("currage","gender"), adjmodel="linear", regcov="currage", cluster="id", noccsamp=T, nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers="y1", adjcov="gender", regcov="gender", sregcov="gender", link="logit", cluster="id", noccsamp=T, nsamp=5000)


### Covariate adjustment
dis <- nnhs2$d
m1 <- nnhs2$y1
m2 <- nnhs2$y2
m3 <- nnhs2$y3

# One marker
test <- rocreg(d="dis",markers="m1",adjcov=c("nnhs2$gender"),adjmodel="stratified",pvcmeth="empirical", nsamp=5000)
test
rocreg(d="dis",markers="m1",adjcov="nnhs2$gender",adjmodel="stratified",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",pvcmeth="empirical", nsamp=5000)

# Multiple markers
test <- rocreg(d="dis", markers=c("nnhs2$y1","nnhs2$y2"), adjcov="nnhs2$gender",adjmodel="stratified",pvcmeth="empirical",nsamp=5000)
test
rocreg(d="dis", markers=c("nnhs2$y1","nnhs2$y2"), adjcov="nnhs2$gender",adjmodel="stratified",pvcmeth="normal",nsamp=5000)
rocreg(d="dis", markers=c("nnhs2$y1","nnhs2$y2"), adjcov="m3",adjmodel="linear",pvcmeth="empirical",nsamp=5000)
rocreg(d="dis", markers=c("nnhs2$y1","nnhs2$y2"), adjcov="m3",adjmodel="linear",pvcmeth="normal",nsamp=5000)

# Multiple adjcov variables
test <- rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",pvcmeth="empirical",nsamp=5000)
test
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",pvcmeth="normal",nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("currage","y3"),adjmodel="linear",pvcmeth="normal",nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("currage","y3"),adjmodel="linear",pvcmeth="empirical",nsamp=5000)

#nostsamp
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",pvcmeth="empirical",nsamp=5000,nostsamp=T)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",pvcmeth="normal",nsamp=5000,nostsamp=T)



### regcov, sregcov with covariate adjustment
# One marker
rocreg(d="dis",markers="m1",adjcov="nnhs2$gender",adjmodel="stratified",regcov="nnhs2$currage",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov="nnhs2$y3",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov="nnhs2$y3",pvcmeth="empirical", nsamp=5000)

rocreg(d="dis",markers="m1",adjcov="nnhs2$gender",adjmodel="stratified",regcov="nnhs2$currage",sregcov="nnhs2$currage",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov="nnhs2$y3",sregcov="nnhs2$y3",pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov="nnhs2$y3",sregcov="nnhs2$y3",pvcmeth="empirical", nsamp=5000)


# Multiple regcov, sregcov markers
test <- rocreg(d="dis",markers="m1",adjcov="nnhs2$gender",adjmodel="stratified",regcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="normal", nsamp=5000)
test
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="empirical", nsamp=5000)

test <- rocreg(d="dis",markers="m1",adjcov="nnhs2$gender",adjmodel="stratified",regcov=c("nnhs2$currage","nnhs2$y3"),sregcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$y3"),sregcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="normal", nsamp=5000)
rocreg(d="dis",markers="m1",adjcov="nnhs2$y2",adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$y3"),sregcov=c("nnhs2$currage","nnhs2$y3"),pvcmeth="empirical", nsamp=5000)


# Multiple adjcov variables
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",regcov=c("nnhs2$currage","nnhs2$gender"),sregcov=c("nnhs2$currage","nnhs2$gender"),pvcmeth="empirical",nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",regcov=c("nnhs2$currage","nnhs2$gender"),sregcov=c("nnhs2$currage","nnhs2$gender"),pvcmeth="normal",nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("currage","y3"),adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$gender"),sregcov=c("nnhs2$currage","nnhs2$gender"),pvcmeth="normal",nsamp=5000)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("currage","y3"),adjmodel="linear",regcov=c("nnhs2$currage","nnhs2$gender"),sregcov=c("nnhs2$currage","nnhs2$gender"),pvcmeth="empirical",nsamp=5000)

#nostsamp
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",regcov="currage",sregcov="currage",pvcmeth="empirical",nsamp=5000,nostsamp=T)
rocreg(dataset="nnhs2", d="d", markers=c("y1"), adjcov=c("sitenum","gender"),adjmodel="stratified",regcov="currage",sregcov="currage",pvcmeth="normal",nsamp=5000,nostsamp=T)







### Pancreatic cancer data set, more options
panCan <- read.csv("http://www.fhcrc.org/science/labs/pepe/book/data/wiedat2b.csv", header = TRUE, sep = ",")
rocreg(dataset="panCan",d="d",markers="y1", nsamp=5000, tiecorr=T)
rocreg(dataset="panCan",d="d",markers="y1", regcov="y2", nsamp=5000)
rocreg(dataset="panCan",d="d",markers="y1", regcov="y2", sregcov="y2", nsamp=5000)
rocreg(dataset="panCan", d="d", markers="y1", pvcmeth="normal",nsamp=5000)

#Link function and interval
rocreg(dataset="panCan", d="d", markers="y1", interval=c(0, 0.1, 10), link="probit", nsamp=5000)
rocreg(dataset="panCan", d="d", markers="y1", link="logit", nsamp=5000)
rocreg(dataset="panCan", d="d", markers="y1", interval=c(0, 0.1, 10), link="logit", nsamp=5000)

#Bootstrap options
rocreg(dataset="panCan", d="d", markers="y1", noccsamp=T, nsamp=5000)

#resfile
dis <- panCan$d
panCan <- cbind(panCan, dis)
panCan <- panCan[,-which(names(panCan)=="d")]
#1 marker - create file
rocreg(dataset="panCan",d="dis",markers="y1", nsamp=5000, resfile="testResfileRocreg")
#1 marker - Try to overwrite existing file
rocreg(dataset="panCan",d="dis",markers="y2", nsamp=5000, resfile="testResfileRocreg")
#Multiple markers
rocreg(dataset="panCan",d="dis",markers=c("y1","y2"), nsamp=5000, resfile="testResfileRocreg", replace=T)
#Multiple markers - Try to overwrite existing file
rocreg(dataset="panCan",d="dis",markers=c("y1","y2"), nsamp=5000, resfile="testResfileRocreg")

#Test replace option
rocreg(dataset="panCan",d="dis",markers="y1", nsamp=5000, resfile="testResfileRocreg", replace=T)
rocreg(dataset="panCan",d="dis",markers="y1", regcov="y2", nsamp=5000, resfile="testResfileRocreg", replace=T)
rocreg(dataset="panCan",d="dis",markers="y1", regcov="y2", sregcov="y2", nsamp=5000, resfile="testResfileRocreg", replace=T)
rocreg(dataset="panCan",d="dis",markers=c("y1","y2"), nsamp=5000, resfile="testResfileRocreg", replace=T)











### Ovarian Cancer dataset
ovCan <- read.csv("http://www.fhcrc.org/science/labs/pepe/book/data/ocdata_b.csv", header = TRUE, sep = ",")
rocreg(dataset="ovCan", d="d", markers=c("y1","y2"), nsamp=5000)
rocreg(dataset="ovCan", d="d", markers="y1", tiecorr=T, pvcmeth="empirical", nsamp=5000)
rocreg(dataset="ovCan", d="d", markers="y1", link="logit", nsamp=5000)



### Daryl error - CIs don't contain estimate
adjCovDat <- read.csv("http://labs.fhcrc.org/pepe/dabs/sj_ms2_fig1_scen1b.csv",header = TRUE, sep = ",")
rocreg(dataset="adjCovDat", d="d", markers="y",level=95, nsamp=5000)
rocreg(dataset="adjCovDat", d="d", markers="y",level=95, nsamp=5000, adjcov = "z", adjmodel = "stratified")





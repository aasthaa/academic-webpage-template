

panCan <- read.csv("http://www.fhcrc.org/science/labs/pepe/book/data/wiedat2b.csv", header = TRUE, sep = ",")


### roccurve
roccurve(dataset="panCan", d="d", markers=c("y1","y2"))
roccurve(dataset="panCan", d="d", markers="y1", tiecorr=TRUE, roc=0.2, pvcmeth="normal",nsamp=100)

#Parametric
roccurve(dataset="panCan", d="d", markers=c("y1","y2"), roc=0.2, rocmeth="parametric", link="logit", nograph=TRUE)
roccurve(dataset="panCan", d="d", markers="y1", roc=0.2, rocmeth="parametric", nograph=TRUE)
roccurve(dataset="panCan", d="d", markers="y1", roc=0.05, rocmeth="parametric", interval=c(0, 0.1, 10), nograph=TRUE)

#Inverse
roccurve(dataset="panCan", d="d", markers="y1", rocinv=0.8)
roccurve(dataset="panCan", d="d", markers="y1", rocinv=0.8, rocmeth="parametric")
roccurve(dataset="panCan", d="d", markers="y1", rocinv=0.8, pvcmeth="normal")
roccurve(dataset="panCan", d="d", markers="y1", rocinv=0.8, pvcmeth="normal", rocmeth="parametric")

# covariates
roccurve(dataset="panCan",d="d",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal", roc=0.05)

#New variable options  (just to check functionality, no need to compare with Stata since the console output shouldn't change)
#pcv
roccurve(dataset="panCan", d="d", markers="y1", roc=0.2, genpcv=TRUE)
roccurve(dataset="panCan", d="d", markers=c("y1","y2"), roc=0.2, genpcv=TRUE)
roccurve(dataset="panCan", d="d", markers=c("y1","y2"), roc=0.2, genpcv=TRUE, replace=TRUE)

#Graph options, no match for this option in Stata
roccurve(dataset="panCan", d="d", markers=c("y1", "y2"), roc=0.2, bw=TRUE)


### Ovarian Cancer dataset
ovCan <- read.csv("http://www.fhcrc.org/science/labs/pepe/book/data/ocdata_b.csv", header = TRUE, sep = ",")
roccurve(dataset="ovCan", d="d", markers=c("y1","y2"))
roccurve(dataset="ovCan", d="d", markers="y1", tiecorr=TRUE, roc=0.2, pvcmeth="normal")
roccurve(dataset="ovCan", d="d", markers="y1", roc=0.2, rocmeth="parametric", link="logit")



###############
###############
###############
### THIS SECTION HAS NO MATCHING ARGUMENTS FOR STATA
# Test c_fpr  #no matching option for Stata
test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_fpr=0.05)
test
test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_fpr=0.05, pvcmeth="normal")
test

# Test c_tpr #no matching option for Stata
test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_tpr=0.8)
test
test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_tpr=0.8, pvcmeth="normal")
test

test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_fpr=0.05, adjmodel="linear",adjcov="y2")
test
test <- roccurve(dataset="panCan",d="d",markers="y1", nsamp=100, c_tpr=0.8, )
test

rm(test)

### COVARIATES

dis <- panCan$d
panCanCov <- cbind(panCan, dis)
panCanCov <- panCanCov[,-which(names(panCanCov)=="d")]
Z <- c(rep(c(1,2),70),1)
T <- c(rep(c(1,2), each=70), 2)
W <- c(rep(c(1,2,3,4),each=35),4)
X <- c(rep(1,135),2,3,4,5,5,5)
C <- c(1,rep(1:70,each=2)) 
panCanCov <- cbind(panCanCov,Z,T,W,X,C)
rm(Z,T,W,X,dis,C)

###########################################
#### EXECUTE THIS TO MAKE DATA FILE FOR STATA
#write.table(panCanCov,"myData.csv",sep=",",row.names=F)

# Adjmodel=stratified
#pvcmeth=emp
test <- roccurve(dataset="panCanCov",d="dis",markers=c("y1","y2"), nsamp=100, c_fpr=0.2, adjcov=c("Z","W"))
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_tpr=0.8, adjcov=c("Z","W"))

#pvcmeth=normal
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_fpr=0.2, adjcov=c("Z","W"), pvcmeth="normal")
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_tpr=0.8, adjcov=c("Z","W"), pvcmeth="normal")

#Adjmodel=linear
#pvcmeth=emp
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_fpr=0.2, adjcov=c("y2"), adjmodel="linear")
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_tpr=0.8, adjcov=c("y2"), adjmodel="linear")

#pvcmeth=normal
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_fpr=0.2, adjcov=c("y2"), adjmodel="linear", pvcmeth="normal")
test <- roccurve(dataset="panCanCov",d="dis",markers="y1", nsamp=100, c_tpr=0.8, adjcov=c("y2"), adjmodel="linear", pvcmeth="normal")

## END OF STUFF TESTING THE OPTIONS THAT STATA DOESN'T HAVE
###############
###############
###############

### COVARIATES

# A) One marker
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical")
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal")
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal")
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical")

## roc(0.05)
#rocmeth=nonparametric
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal",roc=.05,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical",roc=.05,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal",roc=.05,nsamp=100)
#rocmeth=parametric
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical",roc=.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal",roc=.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical",roc=.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal",roc=.05,rocmeth="parametric",nsamp=100)


## rocinv(0.8)
#rocmeth=nonparametric
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical",rocinv=.8,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal",rocinv=.8,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical",rocinv=.8,nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal",rocinv=.8,nsamp=100)
#rocmeth=parametric
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical",rocinv=.8, rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal",rocinv=.8, rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical",rocinv=.8, rocmeth="parametric",nsamp=100)
roccurve(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal",rocinv=.8, rocmeth="parametric",nsamp=100)



# B) Multiple...
Zo       <- c(rep(1,100),rep(2,100),rep(1,500),rep(2,500))
Uo       <- c(rep(seq(1:3),400))
Wo       <- c(rep(1,50),rep(2,50),rep(3,50),rep(4,50),rep(1,250),rep(2,250),rep(3,250),rep(4,250))
y3       <- c(seq(100,1,length=600), seq(50,300,length=600))
ovCanCov <- cbind(ovCan,Zo,Uo,Wo,y3)
rm( Zo,Uo,Wo,y3)

###########################################
#### EXECUTE THIS TO MAKE DATA FILE FOR STATA
#write.table(ovCanCov,"myDataBigger.csv",sep=",",row.names=F)

#...markers
#roc(0.05)
 #rocmeth=nonparametric
roccurve(dataset="ovCanCov", d="d", markers=c("y1","y2"), adjcov="Zo",adjmodel="stratified",pvcmeth="empirical",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1","y2"), adjcov="Zo",adjmodel="stratified",pvcmeth="normal",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1","y2"), adjcov="y3",adjmodel="linear",pvcmeth="empirical",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1","y2"), adjcov="y3",adjmodel="linear",pvcmeth="normal",roc=0.05,nsamp=100)
 #rocmeth=parametric
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov="Zo",adjmodel="stratified",pvcmeth="empirical",roc=0.05,nsamp=100,rocmeth="parametric")
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov="Zo",adjmodel="stratified",pvcmeth="normal",roc=0.05,nsamp=100,rocmeth="parametric")
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov="y3",adjmodel="linear",pvcmeth="empirical",roc=0.05,nsamp=100,rocmeth="parametric")
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov="y3",adjmodel="linear",pvcmeth="normal",roc=0.05,nsamp=100,rocmeth="parametric")

#rocinv(0.8)
 #rocmeth=nonparametric
 #rocmeth=parametric



#...adjcov
#roc(0.05)
 #rocmeth=nonparametric
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("Zo","Uo"),adjmodel="stratified",pvcmeth="empirical",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("Zo","Uo"),adjmodel="stratified",pvcmeth="normal",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("y2","y3"),adjmodel="linear",pvcmeth="empirical",roc=0.05,nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("y2","y3"),adjmodel="linear",pvcmeth="normal",roc=0.05,nsamp=100)
 #rocmeth=parametric
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("Zo","Uo"),adjmodel="stratified",pvcmeth="empirical",roc=0.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("Zo","Uo"),adjmodel="stratified",pvcmeth="normal",roc=0.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("y2","y3"),adjmodel="linear",pvcmeth="empirical",roc=0.05,rocmeth="parametric",nsamp=100)
roccurve(dataset="ovCanCov", d="d", markers=c("y1"), adjcov=c("y2","y3"),adjmodel="linear",pvcmeth="normal",roc=0.05,rocmeth="parametric",nsamp=100)

#rocinv(0.8)
 #rocmeth=nonparametric
 #rocmeth=parametric



# C) dataset=NULL








comproc(d="panCan$d", markers="panCan$y1", nsamp=100)


### comproc
comproc(dataset="panCan", d="d", markers="y1", nsamp=100)
comproc(dataset="panCan", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, nsamp=100)
comproc(dataset="panCan", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100)
comproc(dataset="panCan", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100, pvcmeth="normal")

comproc(dataset="panCan", d="d", markers="y1", nobstrap=TRUE)
comproc(dataset="panCan", d="d", markers="y1", roc=0.2, rocinv=0.8, nobstrap=TRUE)
comproc(dataset="panCan", d="d", markers=c("y1","y2"), auc=TRUE, roc=0.2, nobstrap=TRUE)


# No dataset  (no matching stata commands)
disease <- panCan$d
marker1 <- panCan$y1
marker2 <- panCan$y2
comproc(d="disease", markers="marker1", nsamp=100)
comproc(d="disease", markers=c("marker1","marker2"), auc=TRUE, pauc=0.2, nsamp=100)
comproc(d="disease", markers=c("marker1","marker2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100)
comproc(d="disease", markers=c("marker1","marker2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100,pvcmeth="normal")

comproc(d="disease", markers="marker1", nobstrap=TRUE)
comproc(d="disease", markers="marker1", roc=0.2, rocinv=0.8, nobstrap=TRUE)
comproc(d="disease", markers=c("marker1","marker2"), auc=TRUE, roc=0.2, nobstrap=TRUE)

rm(disease,marker1,marker2)

### Jumbled up panCan (no matching stata commands)
panCan <- read.csv("http://www.fhcrc.org/science/labs/pepe/book/data/wiedat2b.csv", header = TRUE, sep = ",")
panCanMod <- rbind(panCan[50:((dim(panCan))[1]),], panCan[1:49,])

comproc(dataset="panCanMod", d="d", markers="y1", nsamp=100)
comproc(dataset="panCanMod", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, nsamp=100)
comproc(dataset="panCanMod", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100)
comproc(dataset="panCanMod", d="d", markers=c("y1","y2"), auc=TRUE, pauc=0.2, roc=0.2, rocinv=0.8, nsamp=100, pvcmeth="normal")

comproc(dataset="panCanMod", d="d", markers="y1", nobstrap=TRUE)
comproc(dataset="panCanMod", d="d", markers="y1", roc=0.2, rocinv=0.8, nobstrap=TRUE)
comproc(dataset="panCanMod", d="d", markers=c("y1","y2"), auc=TRUE, roc=0.2,  nobstrap=TRUE)

# trying covariate adjustment

# A) One marker
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical")
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal")
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal")
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical")

## roc(0.05)
#rocmeth=nonparametric
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov=c("Z"),adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="Z",adjmodel="stratified",pvcmeth="normal",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="empirical",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",adjcov="y2",adjmodel="linear",pvcmeth="normal",roc=.05,nsamp=100)

#clustering
comproc(dataset="panCanCov",d="dis",markers="y1",cluster="C",
        adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",cluster="C",
         adjmodel="stratified",pvcmeth="normal",roc=.05,nsamp=100)

comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE,
     adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE, 
     adjmodel="stratified",pvcmeth="normal",roc=.05,nsamp=100)

# diabolical test case ... THIS BREAKS the R CODE, and IS SHOULD JUST ERROR
#    OUT NICELY  (we get some weird samples... I think clustering needs to 
#     be done differently... maybe we have to figure out how to handle clusters
#     with both cases and controls)
#comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE,cluster="Z",
#     adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
#comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE, 
#     cluster="Z",adjmodel="stratified",pvcmeth="normal",auc=TRUE,nsamp=100)

comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE,cluster="C",
     adjmodel="stratified",pvcmeth="empirical",roc=.05,nsamp=100)
comproc(dataset="panCanCov",d="dis",markers="y1",noccsamp=TRUE, cluster="C",
     adjmodel="stratified",pvcmeth="normal",auc=TRUE,nsamp=100)







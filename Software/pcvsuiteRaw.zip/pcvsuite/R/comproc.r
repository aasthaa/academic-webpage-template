# Comparison of statistics based on percentile value calculations
comproc <- function(dataset=NULL, d, markers, auc=FALSE, pauc=NULL, 
   roc=NULL, rocinv=NULL, pvcmeth="empirical", tiecorr=FALSE, adjcov=NULL, 
   adjmodel="stratified", nsamp=1000, nobstrap=FALSE, noccsamp=FALSE, 
   nostsamp=FALSE, cluster=NULL, resfile=NULL, replace=FALSE, level=95) {
   
   
   # Called by both pcval and npcval, when adjmodel="linear"
   # Returns percentile values, as well as the model fit
   getLinearPcvals <- function(d,y,adjcovMat,pcvmethod) {
      pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      n_db <- length(d[d==0])
      Y_db <- y[1:n_db]
      y_j <- y[(n_db+1):length(y)]

      ctrlsData <- as.data.frame(cbind(Y_db,adjcovMat[1:n_db,]))
      colnames(ctrlsData) <- c("Y_db", colnames(adjcovMat))
      formulaStr <- paste("Y_db ~", paste(colnames(adjcovMat), collapse="+"))
      mod <- glm(as.formula(formulaStr), data=ctrlsData)
   
    #  sigma <- sd(Y_db)
   
      if(pcvmethod=="empirical") {
         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% t(ctrlsData[,-1])
         mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))
   
         #resid <- (Y_db-mu)/sigma
         resid <- Y_db-mu
         # Calculate CDF of y_j, P(Y_db <= y_j), under no parametric assumption
         F_le <- ecdf(sort(resid))
   
         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                  t(adjcovMat[(n_db+1):length(y),])
         mu_D <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))
   
     #    resid_D <- (y_j - mu_D)/sigma
         resid_D <- y_j - mu_D

         pcvals <- F_le(sort(resid_D))
      }
      else if(pcvmethod=="normal") {
         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                  t(adjcovMat[(n_db+1):length(y),])
         mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))
   
         sigma <- sd(mod$residuals)

         # Calculate CDF of y_j, P(Y_db <= y_j), under Normality assumption
         F_le <- pnorm((y_j-mu)/sigma)
         pcvals <- F_le
      }
      return(list(sort(pcvals), summary(mod)))
   }
   
   
   # Calculate percentile values using empirical method
   # Calls pcval_calc for actual calculations
   pcval <- function(d, y, adjcovMat, adjmodel, tiecorr) {
      pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      # If adjusting for covariates, figure out stratified or linear
      if(!is.null(adjcovMat)) {
         if(adjmodel=="linear") {
            # Similar to what we do in parametric case,
            # except now don't assume normal distn for residuals
            # This is "semiparametric"
            return(getLinearPcvals(d,y,adjcovMat,"empirical"))
         }
         else if(adjmodel=="stratified") {
            stratas <- getStrata(d,y,adjcovMat)
            j <- 1
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
               colnames(currStrata) <- c("d","y",colnames(adjcovMat))
               currD <- currStrata[,1]
               currY <- currStrata[,2]
               pcvals[j:(j+length(currD[currD==1])-1)] <- 
                       pcval_calc(currD, currY, tiecorr)
               j <- j + length(currD[currD==1])
            }
         }
      }
      # If not adjusting for covariates, the usual (entirely empirical) way
      else
         pcvals <- pcval_calc(d,y,tiecorr)

      return(list(sort(pcvals), summary(mod)))
   }
   
   
  
   # Calculate percentile values using parametric (normal distn) method
   # Calls pcval_calc for actual calculations
   npcval <- function(d, y, adjcovMat, adjmodel) {
      pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      # If adjusting for covariates, figure out stratified or linear
      if(!is.null(adjcovMat)) {
         if(adjmodel=="linear") {
            # Assume normal distn for residuals, now including adjcov as
            # covariates in the model
            return(getLinearPcvals(d,y,adjcovMat,"normal"))
         }
         else if(adjmodel=="stratified") {
            stratas <- getStrata(d,y,adjcovMat)
            j <- 1
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
               currD <- currStrata[,1]
               currY <- currStrata[,2]
               pcvals[j:(j+length(currD[currD==1])-1)] <- npcval_calc(currD, currY)
               j <- j + length(currD[currD==1])
            }
         }
      }
      # If not adjusting for covariates, the usual (entirely empirical) way
      else
         pcvals <- npcval_calc(d,y)

      return(list(sort(pcvals), summary(mod)))
   }
   
   
   # Bootstrap CIs
   rocbsC <- function(statistic, bstrapResMat, bstrapResMatNames) {
     # set.seed(51)
      alpha <- 1 - (level/100)
 
      if(delta) {
      #   thetahat.star1 <- replicate(nsamp, do.oneC(1, statistic))
      #   thetahat.star2 <- replicate(nsamp, do.oneC(2, statistic))
         thetahat.starMat <- replicate(nsamp, do.oneC(c(1,2), statistic))
         thetahat.star1 <- thetahat.starMat[1,]
         thetahat.star2 <- thetahat.starMat[2,]

         thetahat.star <- thetahat.star2 - thetahat.star1
         CImat <- matrix(nrow=3,ncol=3)
         CImat[1,2:3] <- t(apply(matrix(thetahat.star1), 2, function(z) {
                            quantile(z, c(alpha/2, (1 - alpha/2)))}))
         CImat[1,1] <- sd(thetahat.star1)
         CImat[2,2:3] <- t(apply(matrix(thetahat.star2), 2, function(z) {
                            quantile(z, c(alpha/2, (1 - alpha/2)))}))
         CImat[2,1] <- sd(thetahat.star2)
         CImat[3,2:3] <- t(apply(matrix(thetahat.star), 2, function(z){
                            quantile(z, c(alpha/2, (1 - alpha/2)))}))
         CImat[3,1] <- sd(thetahat.star)
         if(!is.null(bstrapRes)) {
            bstrapResMat <- cbind(bstrapResMat,thetahat.star1,thetahat.star2,
                                  thetahat.star)
            #bstrapResMatNames <- c(bstrapResMatNames, paste( paste(statistic,"1",sep=""),
            #   paste(statistic,"2",sep=""),paste(statistic,"_delta",sep=""),sep="," ))
            bstrapResMatNames <- c(bstrapResMatNames, paste(statistic,"1",sep=""),
               paste(statistic,"2",sep=""), paste(statistic,"_delta",sep="") )
         }
      }
      else {
         thetahat.star <- replicate(nsamp, do.oneC(1, statistic))
         CImat <- matrix(nrow=1,ncol=3)
         CImat[1,2:3] <- t(apply(matrix(thetahat.star), 2, 
                           function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
         CImat[1,1] <- sd(thetahat.star)
         if(!is.null(bstrapRes)) {
            bstrapResMat <- cbind(bstrapResMat,thetahat.star)
            bstrapResMatNames <- c(bstrapResMatNames, statistic)
         }
      }
      return(list(CImat, bstrapResMat, bstrapResMatNames))
   }



   do.oneC <- function(i, statistic) {
      newAdjcovMat <- NULL
      firstI <- length(i)
      if(adjust & adjmodel=="stratified" & nostsamp==FALSE) {
         strata <- getStrata(d_vector,y[,firstI],adjcovMat)
         resample.ctrl <- NULL
         resample.case <- NULL
         resample.cohort <- NULL
         for(s in 1:length(strata)) {
            resampIds <- as.numeric(rownames(strata[[s]]))
            strataCluster <- clusterIDs[resampIds]
            resample <- getBstrapSample(strata[[s]],noccsamp, cluster,
                           clusterUniqueMat, cListFull[[s]], strataCluster)
            if(!noccsamp) {
               resample.ctrl <- c(resample.ctrl, resampIds[resample[[1]]])
               resample.case <- c(resample.case, resampIds[resample[[2]]])
            } else {
               resample.cohort <- c(resample.cohort, resampIds[resample])
            }
         }
      } else {
         resample <- getBstrapSample(dataset_ordered,noccsamp, cluster,
                                     clusterUniqueMat, cListFull)
         if(!noccsamp) {
            resample.ctrl <- resample[[1]]
            resample.case <- resample[[2]]
         } else {
            resample.cohort <- resample
         }
      }

      #We have the resampled indices. Put together the new dataset
      if(!noccsamp) {
         if(length(i) > 1) { 
           newdata <- cbind( 
                        c(rep(0,length(resample.ctrl)),
                          rep(1,length(resample.case))), 
                        rbind(y[resample.ctrl,i],y[resample.case,i]) )
         } else {
           newdata <- cbind( 
                        c(rep(0,length(resample.ctrl)),
                          rep(1,length(resample.case))), 
                        c(y[resample.ctrl,i],y[resample.case,i]) )
         }
         if(adjust) {
            for(a in 1:length(adjcov)) {
               newAdjcovMat <- cbind(newAdjcovMat,c(adjcovMat[resample.ctrl,a], 
                  adjcovMat[resample.case,a]))
            }
            newAdjcovMat <- as.data.frame(newAdjcovMat)
            colnames(newAdjcovMat) <- adjcov
            newdata <- cbind( newdata, newAdjcovMat )
         }
      } else {
         newdata <- cbind((dataset_ordered$d)[resample.cohort], y[resample.cohort,i] )
         orderD <- order(newdata[,1])
         newdata <- newdata[orderD,]

         if(adjust) {
            newAdjcovMat <- as.data.frame(adjcovMat[resample.cohort,])
            newAdjcovMat <- as.data.frame(newAdjcovMat[orderD,])
            colnames(newAdjcovMat) <- adjcov
            newdata <- cbind( newdata, newAdjcovMat )
         }
      }

      retVal <- rep(0,length(i))
      for(j in 1:length(i)) {
        if(length(i) > 1) {
          removeY <- (1 + (1:length(i)))[-j]
          newdataC <- data.frame(newdata[,-removeY])
        } else {
          newdataC <- data.frame(newdata)
        }
        if( adjust & (adjmodel=="linear" | (adjmodel=="stratified" & nostsamp==FALSE))) {
          colnames(newdataC) <- c("d", "y", adjcov)
        } else colnames(newdataC) <- c("d", "y", NULL)


        # Generate new percentile values
        if(pvcmeth=="empirical") {
          newPcvals <- (pcval(newdataC$d, newdataC$y, newAdjcovMat, adjmodel, tiecorr))[[1]]
        } else {
          newPcvals <- (npcval(newdataC$d, newdataC$y, newAdjcovMat, adjmodel))[[1]]
        }
        # Calculate statistic based on new percentile values
        if(statistic=="auc") {retVal[j] <- calcAuc(newPcvals)
        } else if(statistic=="pauc") {retVal[j] <- pauct(newPcvals)
        } else if(statistic=="roc") { retVal[j] <- roct(newPcvals)
        } else if(statistic=="rocinv") {retVal[j] <- calcRocinv(newPcvals)}
      }
      retVal         
   }


   # Get ROC value at given t
   roct <- function(in_pcvals) {
      F_pl <- ecdf(1-in_pcvals)
      return(F_pl(t))
   }



   # Get inverse of ROC function, at a given TPF=v
   calcRocinv <- function(in_pcvals) {
      FPF_new <- 1-in_pcvals
      cFPF_new <- ecdf(FPF_new)
      TPF_new <- cFPF_new(FPF_new)
      result <- min( FPF_new[which(TPF_new >= v)] )
      return( ifelse( length(FPF_new)==0, 1, result ) )
   }


   # Get AUC for ROC curve
   calcAuc <- function(in_pcvals) {
      return(mean(in_pcvals))
   }

   # Get partial AUC for ROC curve, at a given t
   pauct <- function(in_pcvals) {
      pa <- sapply(in_pcvals - (1-pauc), function(x) max(x, 0))
      return(mean(pa))
   }


   checkErrorsComproc <- function() {
      if(length(unique(d_vector))!=2) cat("d must take on two values\n")
      else if(min(d_vector)!=0 | max(d_vector)!=1) cat("d must be 0/1\n")
      else if(is.null(y[,1])) cat(paste(markers[1],"must contain values\n"))
      else if(!(pvcmeth=="empirical"|pvcmeth=="normal"))
         cat("pvcmeth option must be either empirical or normal if specified\n")
#      else if(!(rocmeth=="nonparametric"|rocmeth=="parametric"))
#         cat("rocmeth option must be either parametric or nonparametric if specified\n")
#      else if(!(link=="probit"|link=="logit"))
#         cat("link option must be either probit or logit if specified\n")

      # Check pauc(f), roc(f) and rocinv(t) syntax
      else if( !is.null(pauc) && (!(pauc>0 & pauc<1) | !is.numeric(pauc)) )
         cat("argument for pauc option must be between 0 & 1\n")
      else if( !is.null(roc) && (!(roc>0 & roc<1) | !is.numeric(roc)) )
         cat("argument for roc option must be between 0 & 1\n")
      else if( !is.null(rocinv) && (!(rocinv>0 & rocinv<1) | !is.numeric(rocinv)) )
         cat("argument for rocinv option must be between 0 & 1\n")

      # Check sampling variability options
      else if(!is.numeric(nsamp) | (nsamp<1 & nsamp!=0))
         cat("nsamp argument must be >1\n")

      # Check interval() option arguments
#      else if(!(interval[1]>=0 & interval[1]<=1 & interval[2]>=0 & interval[2]<=1))
#         cat("first two interval arguments, a & b, must be between 0 & 1\n")
#      else if(interval[2] <= interval[1]) cat("interval arguments must satisfy a < b\n")
#      else if(!((interval[3]/as.integer(interval[3]))==1 & interval[3]>0))
#         cat("3rd interval argument, np, must be a positive integer\n")

      # Check covariate adjustment options
      else if(!(adjmodel=="stratified"|adjmodel=="linear"))
         cat("adjmodel option must be either linear or stratified if specified\n")
      else if(!is.null(adjcov) & adjmodel=="stratified" & isStrataCtrlLow(d_vector,adjcovMat,2)) 
         cat("fewer than 2 controls in some case-containing strata defined by 
         stratification variable adjcov.  Need to redefine/broaden adjustment 
         strata specified by adjcov\n")

      # Not in Stata code. My own additions
#      else if(!(ordinal==TRUE | ordinal==FALSE))
#         cat("ordinal option must be TRUE or FALSE, if specified\n")
      else if(!(tiecorr==TRUE | tiecorr==FALSE))
         cat("tiecorr option must be TRUE or FALSE, if specified\n")
      else if(!(noccsamp==TRUE | noccsamp==FALSE))
         cat("noccsamp option must be TRUE or FALSE, if specified\n")
      else if(!(nostsamp==TRUE | nostsamp==FALSE))
         cat("nostsamp option must be TRUE or FALSE, if specified\n")
      else if(!(level>0 & level<100))
         cat("level option must be between 0 & 100, if specified\n")
      else if(!(replace==TRUE | replace==FALSE))
         cat("replace option must be TRUE or FALSE, if specified\n")
      else if(!(nobstrap==TRUE | nobstrap==FALSE))
         cat("nobstrap option must be TRUE or FALSE, if specified\n")

      else return(FALSE)
      return(TRUE)
   }


   printEsts <- function(statSmall, statCaps, in_resultsList) {
      results <- in_resultsList[[1]]
      bstrapResMat <- in_resultsList[[2]]
      bstrapResMatNames <- in_resultsList[[3]]

      if(!nobstrap) {
         cat("\n************\n\n")
         if(nmark==1)
            cat(paste(statCaps, "estimate", "\n"))
         else {
            cat(paste(statCaps, "estimates and difference,", "\n"))
            cat(paste("test 2 - test 1 (", statSmall, "delta)", "\n\n", sep=""))
         }
         if(statSmall=="pauc") cat(paste("partial AUC for f <", pauc, "\n\n"))
         else if(statSmall=="roc") cat(paste("ROC(f) @ f =", roc, "\n\n"))
         else if(statSmall=="rocinv") cat(paste("ROC^(-1)(t) @ t =", rocinv, "\n\n"))

         cat( paste( "Bootstrap Results\t\t\tNumber of obs\t= ",
                    (dim(dataset_ordered))[1], "\n" ) )
         cat( paste( "\t\t\t\t\tReplications\t= ", nsamp, "\n\n" ) )
      }

      output <- NULL
      estRownames <- NULL
      ests <- vector(length=nmark)
      estsRaw <- vector(length=nmark)
      rocbsResult <- list(NULL, NULL, NULL)
      if(!nobstrap) {
        rocbsResult <- rocbsC(statistic=statSmall,bstrapResMat, bstrapResMatNames)
        CImat <- signif(rocbsResult[[1]],3)
      }
      for(i in 1:nmark) {
         if(statSmall=="auc") {
            estsRaw[i] <- calcAuc(pcvals[i,])
         } else if(statSmall=="pauc") {
            estsRaw[i] <- pauct(pcvals[i,])
         } else if(statSmall=="roc") {
            estsRaw[i] <- roct(pcvals[i,])
         } else if(statSmall=="rocinv") {
            estsRaw[i] <- calcRocinv(pcvals[i,])
         }
         ests[i] <- signif(estsRaw[i], 3)
         if(!nobstrap) {
            output <- rbind(output, c(ifelse(nmark==1,statSmall,
                        paste(statSmall,i,sep="")), ests[i], CImat[i,1], 
                        paste("(",CImat[i,2],", ",CImat[i,3],")", sep="")))
         }
         estRownames <- c(estRownames, ifelse(nmark==1,statSmall,paste(statSmall,i,sep="")) )
      }
      results <- c(results, ests)
      names(results) <- c((names(results))[1:(length(names(results))-nmark)], estRownames)

      if(nmark>1) {
         estdelta <- signif(estsRaw[2]-estsRaw[1],3)
         results <- c(results, estdelta)
         names(results) <- c( (names(results))[1:(length(names(results))-1)], 
            paste(statSmall,"delta",sep=""))
         if(!nobstrap) {
            output <- rbind(output, c(paste(statSmall,"delta",sep=""), estdelta, 
               CImat[3,1], paste("(",CImat[3,2],", ",CImat[3,3],")", sep="")))
            rownames(output) <- rep("", nmark+1)
            results <- c(results, as.vector(CImat[,1]))
            names(results) <- c((names(results))[1:(length(names(results))-3)],
               paste("se_",statSmall,"1",sep=""), 
               paste("se_",statSmall,"2",sep=""),
               paste("se_",statSmall,"delta",sep=""))
         }
      }
      else {
         if(!nobstrap) {
            rownames(output) <- rep("", nmark)
            results <- c(results, CImat[,1])
            names(results) <- c( (names(results))[1:(length(names(results))-1)], 
               paste("se_",statSmall,sep="") )
         }
      }
      if(!nobstrap) {
         colnames(output) <- c("", "Observed Coef.", "Bootstrap Std. Err.", 
                           paste("[", level, "% Conf. Interval", "]", sep=""))
         print(format(output, justify="centre"), quote=FALSE)

         cat("\n************\n\n")
         if(nmark > 1) {
            cat(paste("test of Ho: ",output[1,1]," = ", output[2,1], "\n"))
            zstat =  estdelta / CImat[3,1]
            pval =  2*(1-pnorm(abs(zstat)))
            cat(paste("  z = ",signif(zstat,3), 
                      "    p = ",signif(pval,3),"\n",sep=""))
         }
      }
      return(list(results,rocbsResult[[2]],rocbsResult[[3]]))
   }

   ### END OF HELPER FUNCTIONS DEFINITIONS



   # Assign general variables
   nmark <- length(markers)
   delta <- ifelse(nmark==1, FALSE, TRUE)
   if(!auc && is.null(pauc) && is.null(roc) && is.null(rocinv)) auc <- TRUE
   if(pvcmeth=="") pvcmeth <- "empirical"
   if(nsamp==0) nobstrap <- TRUE
   t <- roc
   v <- rocinv
   adjust <- ifelse(!is.null(adjcov), TRUE, FALSE)
   nStrata <- 1

   results <- NULL   # Store results to return
   names(results) <- NULL

   #Do error checking and create working dataset
   #If dataset variable is specified
   if(!is.null(dataset)) {
      # Check that specified dataset is valid
      if(!exists(dataset))
         stop("Specified dataset does not exist\n")

      # Check that specified disease marker is valid
      if(!(d %in% names(eval(parse(text=dataset)))) )
         stop("Specified disease marker does not exist\n")

      # Check that specified marker vectors specified are valid
      if(sum(markers %in% names(eval(parse(text=dataset))))<length(markers) ) 
         stop("At least one of the specified test markers does not exist\n")

      # Disease and test markers exist - start creating working dataset
      working_dataset <- as.data.frame(eval(parse(text=paste(dataset,"$",d,sep=""))))
#      localMarkers <- NULL
      for(i in 1:nmark)
         working_dataset <- cbind(working_dataset, 
                                  eval(parse(text=paste(dataset,"$",markers[i],sep=""))))
#       localMarkers <- c(localMarkers, paste("y",i,sep=""))
#       colnames(working_dataset) <- c((colnames(working_dataset))[-(i+1)], localMarkers[i])

      # Check that specified adjcov markers specified are valid. If so, add to working dataset
      if(!is.null(adjcov)) {
         if(sum(adjcov %in% names(eval(parse(text=dataset))))<length(adjcov) ) 
            stop("At least one of the specified adjcov markers does not exist\n")
         else {
            for(i in 1:length(adjcov))
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(dataset,"$",adjcov[i],sep=""))))
         }
      }
      # Check that specified cluster variables are valid. If so, add to working dataset
      if(!is.null(cluster)) {
         if(sum(cluster %in% names(eval(parse(text=dataset))))<length(cluster) ) 
            stop("At least one of the specified cluster variables does not exist\n")
         else {
            for(i in 1:length(cluster))
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(dataset,"$",cluster[i],sep=""))))
         }
      }
      colnames(working_dataset) <- c(d,markers,adjcov,cluster)
   } else {  #If dataset variable is not specified
      working_dataset_colnames <- NULL
      # Check that specified disease marker is valid
      splitVar <- strsplit(d,"$",fixed=TRUE)
      if(length(splitVar[[1]]) == 1) {
         if(!exists(d))
            stop("Specified disease marker does not exist\n")
         working_dataset_colnames <- d
         working_dataset <- as.data.frame(eval(parse(text=d)))
      }
      else {
         if(!((splitVar[[1]])[2] %in% names(eval(parse(text=(splitVar[[1]])[1])))) )
            stop("Specified disease marker does not exist\n")
         working_dataset_colnames <- (splitVar[[1]])[2]
         working_dataset <- as.data.frame(eval(parse(text=d)))
         d <- (splitVar[[1]])[2]
      } 

      # Check that specified marker vectors specified are valid
      splitVar <- strsplit(markers,"$",fixed=TRUE)
      for(i in 1:length(markers)) {
         if(length(splitVar[[i]]) == 1) {
            if(!exists(markers[i]))
               stop("At least one of the specified test markers does not exist\n")
            working_dataset_colnames <- c(working_dataset_colnames, markers[i])
            working_dataset <- cbind(working_dataset, eval(parse(text=paste(markers[i],sep=""))))
         }
         else {
            if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
               stop("At least one of the specified test markers does not exist\n")
            working_dataset_colnames <- c( working_dataset_colnames, (splitVar[[i]])[2] )
            working_dataset <- cbind(working_dataset, eval(parse(text=paste(markers[i],sep=""))))
            markers[i] <- (splitVar[[i]])[2]
         }
      }

      # Check that specified adjcov markers specified are valid
      if(!is.null(adjcov)) {
         splitVar <- strsplit(adjcov,"$",fixed=TRUE)
         for(i in 1:length(adjcov)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(adjcov[i]))
                  stop("At least one of the specified adjcov variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, adjcov[i])
               working_dataset <- cbind(working_dataset, eval(parse(text=paste(adjcov[i],sep=""))))
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified adjcov variables does not exist\n")
               working_dataset_colnames <- c( working_dataset_colnames, (splitVar[[i]])[2] )
               working_dataset <- cbind(working_dataset, eval(parse(text=paste(adjcov[i],sep=""))))
               adjcov[i] <- (splitVar[[i]])[2]
            } 
         }
      }
      # Check that specified cluster variables are valid
      if(!is.null(cluster)) {
         splitVar <- strsplit(cluster,"$",fixed=TRUE)
         for(i in 1:length(cluster)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(cluster[i]))
                  stop("At least one of the specified cluster variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, cluster[i])
               working_dataset <- cbind(working_dataset, eval(parse(text=paste(cluster[i],sep=""))))
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified cluster variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, (splitVar[[i]])[2])
               working_dataset <- cbind(working_dataset, eval(parse(text=paste(cluster[i],sep=""))))
               cluster[i] <- (splitVar[[i]])[2]
            }
         }
      }
      colnames(working_dataset) <- working_dataset_colnames
#      markers <- working_dataset_colnames[2:(1+length(markers))]
#      adjcov <- working_dataset_colnames[(1+length(markers)+1):(1+length(markers)+1+length(adjcov))]
#      cluster <- working_dataset_colnames[(1+length(markers)+1+length(adjcov)+1):
#         (1+length(markers)+1+length(adjcov)+1+length(cluster))] 
   }

   #Order dataset by disease status, to give final working dataset
   dataset_ordered <- working_dataset[order(eval(parse(text=paste("working_dataset$",d,sep="")))),]




   #### First round of error checking done. Working dataset created.
#   # Create data vectors, d_vector and y
#   if(is.null(dataset)) {
#      working_dataset <- as.data.frame(eval(parse(text=d)))
#      colnames(working_dataset) <- "d"
#      localMarkers <- NULL
#      for(i in 1:nmark) {
#         working_dataset <- cbind(working_dataset, eval(parse(text=paste(markers[i],sep=""))))
#         localMarkers <- c(localMarkers, paste("y",i,sep=""))
#         colnames(working_dataset) <- c((colnames(working_dataset))[-(i+1)], localMarkers[i])
#      }
#      dataset_ordered <- working_dataset[order(eval(parse(text="working_dataset$d"))),]
#   }
#   else {
#      dataset_ordered <- eval(as.symbol(dataset))[order(eval(parse(text=paste(dataset,
#         "$",d,sep="")))),]
#      localMarkers <- markers
#   }

   missingDataRows <- (which(is.na(dataset_ordered), arr.ind=TRUE))[,1]
   if(length(missingDataRows)>0) 
      dataset_ordered <- dataset_ordered[-missingDataRows,]

##### Fix after checking what dataset_ordered column names are
#   if(is.null(dataset))
#      d_vector <- eval(parse(text=paste("dataset_ordered$","d",sep="")))
#   else
      d_vector <- eval(parse(text=paste("dataset_ordered$",d,sep="")))

   y <- matrix(nrow=(dim(dataset_ordered))[1], ncol=nmark)
   for(i in 1:nmark)
      y[,i] <- eval(parse(text=paste("dataset_ordered","$",markers[i],sep="")))
#      y[,i] <- eval(parse(text=paste("dataset_ordered","$",localMarkers[i],sep="")))

   adjcovMat <- NULL
   if(adjust) {
      adjcovMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(adjcov))
      for(i in 1:length(adjcov))
         adjcovMat[,i] <- eval(parse(text=paste("dataset_ordered","$",adjcov[i],sep="")))
      adjcovMat <- data.frame(adjcovMat)
      colnames(adjcovMat) <- adjcov
   }


   clusterMat <- NULL
   clusterUniqueMat <- NULL
   clusterIDs <- vector(length=(dim(dataset_ordered)[1]))
   if(!is.null(cluster)) {
      clusterMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(cluster))
      for(i in 1:length(cluster))
         clusterMat[,i] <- eval(parse(text=
                              paste("dataset_ordered","$",cluster[i],sep="")))
      clusterMat <- data.frame(clusterMat)
      colnames(clusterMat) <- cluster
      clusterUniqueMat <- unique(as.data.frame(cbind(d_vector,clusterMat)))
      colnames(clusterUniqueMat) <- c(d,cluster)
      for(s in 1:(dim(clusterUniqueMat)[1])) {
         currCluster <- as.data.frame(cbind(d_vector, clusterMat, 
                                      seq(1:(dim(dataset_ordered)[1]))))
         colnames(currCluster) <- c(d,cluster,"origDatasetID")
##         currCluster <- as.data.frame(cbind(dataset_ordered,
##                                      seq(1:(dim(dataset_ordered)[1]))))
##         colnames(currCluster) <- c(names(dataset_ordered),"origDatasetID")
         for(k in 1:length(cluster)) {
            currCluster <- currCluster[which(as.numeric(eval(parse(
                            text=paste("currCluster$",cluster[k],sep="")))) == 
                            clusterUniqueMat[s,k+1]),]
         }
         currCluster <- currCluster[which(
                    eval(parse(text=paste("currCluster$",d,sep=""))) == 
                    eval(parse(text=paste("clusterUniqueMat$",d,sep="")))[s]),]
         clusterIDs[currCluster$origDatasetID] <- s
      }
   }


   # calculate cluster lists
   if(!is.null(cluster)) { 
      if(adjust & adjmodel=="stratified" & nostsamp==FALSE) {
         cListFull <- list()
         strata <- getStrata(d_vector,y[,1],adjcovMat)
         for(s in 1:length(strata)) {
            resampIds <- as.numeric(rownames(strata[[s]]))
            cListFull[[s]] <- makeClist(clusterIDs[resampIds])
         }
      } else {
         cListFull <- makeClist(clusterIDs)
      }
   }

   # Proceed if no more errors in variables
   isError <- checkErrorsComproc()

   if(!isError) {

      if(adjust & adjmodel=="stratified" & isStrataCtrlLow(d_vector,adjcovMat,10)) {
         cat("Warning: fewer than 10 controls in some case-containing strata defined by 
            stratification variable adjcov\n")
      }

      bstrapRes <- NULL
      bstrapResMat <- NULL
      bstrapResMatNames <- NULL
      # Create file to store bootstrap results
      if(!nobstrap) {
         if(!is.null(resfile)) {
            fileExists <- file.exists(paste(resfile,".txt",sep=""))
            if(!fileExists || (fileExists && replace==TRUE) ) {
               bstrapRes <- file(paste(resfile,".txt",sep=""), open="w")  # open an output file connection
            }
            else {
               stop("file specified by resfile already exists, use 'replace' 
                     option to replace existing file\n\n")
            }
         }
      }

      # Generate percentile values
      pcvalResults <- vector("list",length=2)
      pcvals <- matrix(nrow=nmark, ncol=length(d_vector[d_vector==1]), byrow=TRUE)
      # if(adjust & adjmodel=="linear")
      linModels <- vector("list",length=nmark)

      if(pvcmeth=="empirical") {
         for(i in 1:nmark) {
            pcvalResults <- pcval(d=d_vector, y=y[,i], adjcovMat, adjmodel, tiecorr) 
            pcvals[i,] <- pcvalResults[[1]]
            linModels[[i]] <- pcvalResults[[2]]
         }
      }
      else {
         for(i in 1:nmark) {
            pcvalResults <- npcval(d=d_vector, y=y[,i], adjcovMat, adjmodel)
            pcvals[i,] <- pcvalResults[[1]]
            linModels[[i]] <- pcvalResults[[2]]
         }
      }

      # Generate placement values
      plvals <- 1-pcvals


      #labels <- vector(length=nmark)
      #if(label(y1) == "")
      #   label(y1) <- "y1"
      #labels[1] <- label(y1)
      #if(!is.null(y2)) {
      #   if(label(y2) == "")
      #      label(y2) <- "y2"
      #   labels[2] <- label(y2)
      #}



      # Output specified options
      outOpts_markers <- NULL
      for(i in 1:nmark)
         outOpts_markers <- rbind(outOpts_markers, paste("test ", i, ": ", markers[i], sep="") )
      rownames(outOpts_markers) <- rep("",nmark)
      if(nmark == 1)
         colnames(outOpts_markers) <- "ROC statistics"
      else
         colnames(outOpts_markers) <- "Comparison of test measures"
      print(outOpts_markers, quote=FALSE)

#      outOpts_rocmeth <- NULL
#      outOpts_rocmeth <- rbind(outOpts_rocmeth, ifelse(rocmeth=="nonparametric", 
#         "non-parametric (Empirical ROC)", "parametric"))
#      rownames(outOpts_rocmeth) <- "ROC method:"
#      colnames(outOpts_rocmeth) <- ""
#      print(outOpts_rocmeth, quote=FALSE)

#      outOpts_rocparam <- NULL
#      if(rocmeth=="parametric") {
#         outOpts_rocparam <- rbind(outOpts_rocparam, ifelse(link=="probit", "probit - 
#            binormal ROC", "logit - bilogistic ROC"))
#         outOpts_rocparam <- rbind(outOpts_rocparam, np)
#         outOpts_rocparam <- rbind(outOpts_rocparam, paste("(", a, ",", b, ")", sep=""))
#         rownames(outOpts_rocparam) <- c("link function:", "number of points:", "on FPR interval:")
#         colnames(outOpts_rocparam) <- ""
#         cat("\nGLM fit")
#         print(outOpts_rocparam, quote=FALSE)
#      }

      outOpts_pvcmeth <- NULL
      outOpts_pvcmeth <- rbind(outOpts_pvcmeth, pvcmeth)
      if(pvcmeth=="empirical") {
         outOpts_pvcmeth <- rbind(outOpts_pvcmeth, ifelse(tiecorr==FALSE, "no", "yes"))
         rownames(outOpts_pvcmeth) <- c("method:", "tie correction:")
      }
      else
         rownames(outOpts_pvcmeth) <- "method:"
      colnames(outOpts_pvcmeth) <- ""
      cat("\nPercentile value calculation")
      print(outOpts_pvcmeth, quote=FALSE)

      if(adjust) {
         outOpts_covAdj <- ifelse(adjmodel=="stratified", "stratified", "linear model")
         outOpts_covAdj <- rbind(outOpts_covAdj, paste(adjcov, collapse=", "))
         rownames(outOpts_covAdj) <- c("method:", "covariates:")
         colnames(outOpts_covAdj) <- ""
         cat("\nCovariate adjustment")
         print(outOpts_covAdj, quote=FALSE)

         if(adjmodel=="stratified") {
            stratas <- getStrata(d_vector,y[,1],adjcovMat)

            dCount <- matrix(nrow=length(stratas),ncol=2)
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
             #  dCount[s,1] <- eval(parse(text=
             #           paste("dim(subset(currStrata,",d,"==0))[1]",sep="")))
             #  dCount[s,2] <- eval(parse(text=
             #           paste("dim(subset(currStrata,",d,"==1))[1]",sep="")))
               dCount[s,1] <- length(which(currStrata[,1]==0))
               dCount[s,2] <- length(which(currStrata[,1]==1))		
            }
            dCount <- cbind(seq(1:length(stratas)), dCount, 
                            dCount[,1]+dCount[,2])
            colnames(dCount) <- c("Stratum",paste(d,"=0",sep=""),
                                  paste(d,"=1",sep=""),"Total")
            rownames(dCount) <- rep("",dim(dCount)[1])
            dCount <- rbind(dCount, c("Total", sum(dCount[,2]),
                                  sum(dCount[,3]), sum(dCount[,4])))
            cat(paste("# of case-containing strata:",length(stratas),"\n\n"))
            print(dCount, quote=FALSE)
         }
         else {
            for(i in 1:nmark) {
               cat("\n\n************\n\n")
               cat("Covariate adjustment - linear model, controls only\n")
               cat( paste("Model results for marker:",markers[i],"\n") )
               print(linModels[[i]])
            }
         }
      }

      resultsList <- list(results, bstrapResMat, bstrapResMatNames)

      if(!nobstrap) {
         #Sampling options
         cat("\nbootstrap percentile CI's based on sampling\n")
         sampDesign <- ifelse(noccsamp==FALSE, 
            "separately from cases and controls\n", 
            "w/o respect to case/control status\n")
         cat(sampDesign)
         if(adjust & adjmodel=="stratified")
            cat("and from within covariate strata\n")

         cat( paste("\nbootstrap samples:",nsamp,"\n") )

         if(auc) resultsList <- printEsts("auc", "AUC", resultsList )
         if(!is.null(pauc)) resultsList <- printEsts("pauc", "pAUC", resultsList )
         if(!is.null(roc)) resultsList <- printEsts("roc", "ROC", resultsList )
         if(!is.null(rocinv)) resultsList <- printEsts("rocinv", "ROC^(-1)(t)", resultsList )

#         printEsts(auc,pauc,roc,rocinv,resultsList)

         results <- resultsList[[1]]
         bstrapResMat <- resultsList[[2]]
         bstrapResMatNames <- resultsList[[3]]

      }
      else {
         cat("\nno bootstrap sampling specified.\n")
         cat("bootstrap-based se's, CI's, and test statistics will not be calculated.\n")

         if(auc) resultsList <- printEsts("auc", "AUC", resultsList )
         if(!is.null(pauc)) resultsList <- printEsts("pauc", "pAUC", resultsList )
         if(!is.null(roc)) resultsList <- printEsts("roc", 
                                        paste("ROC","(",roc,")",sep=""), resultsList )
         if(!is.null(rocinv)) resultsList <- printEsts("rocinv", 
                                        paste("ROC^(-1)(",rocinv,")",sep=""), resultsList )

         results <- resultsList[[1]]
         bstrapResMat <- resultsList[[2]]
         bstrapResMatNames <- resultsList[[3]]

         if(nmark==1) {
            noBstrapOutput <- matrix(signif(results,3), ncol=1)
            colnames(noBstrapOutput) <- c("test1")
         }
         else {
            noBstrapOutput <- matrix(signif(results,3), ncol=3, byrow=TRUE)
            colnames(noBstrapOutput) <- c("test1", "test2", "difference")
         }
         rownameStr <- NULL
         if(auc) rownameStr <- c(rownameStr, "AUC")
         if(!is.null(pauc)) rownameStr <- c(rownameStr , paste("pAUC","(",pauc,")",sep=""))
         if(!is.null(roc)) rownameStr <- c(rownameStr, paste("ROC","(",roc,")",sep=""))
         if(!is.null(rocinv)) rownameStr <- c(rownameStr, paste("ROC^(-1)(",rocinv,")",sep=""))
         rownames(noBstrapOutput) <- rownameStr
         print(format(noBstrapOutput, justify="centre"), quote=FALSE)

      }

      # If resfile option specified, write bootstrap results to resfile
      if(!is.null(bstrapRes)) {
         cat(paste(bstrapResMatNames, collapse=","), file=bstrapRes, fill=TRUE)
         apply( bstrapResMat, 1, function(x){
                 cat(paste(x,collapse=","), file=bstrapRes, append=TRUE, fill=TRUE)} )
         close(bstrapRes)
      }

      invisible(results)
      #invisible(estimates)
      
   }
}




## Get inverse of ROC function, at a given TPF=v
#rocinv <- function(v, dataset, d, y, tiecorr=0, pvcmeth="empirical") {
#	d_new <- 1-d
#	y_new <- -y
#	dataset_new <- as.data.frame(cbind(y_new, d_new))
#	dataset_new <- dataset_new[order(dataset_new$d_new),]
#
#	if(pvcmeth=="empirical")
#		pcvals <- pcval(dataset_new$d_new, dataset_new$y_new, tiecorr)
#	else
#		pcvals <- npcval(dataset_new$d_new, dataset_new$y_new)
#
#	FPF_new <- 1-pcvals
#	F_pl_new <- ecdf(FPF_new)
#	TPF_new <- F_pl_new(FPF_new)
#
#	return(1 - F_pl_new(1-v))
#}
#         ##New definition
#         if(pvcmeth=="empirical")
#            pcvals <- (pcval(d, y, inAdjcovMat, adjmodel, tiecorr))[[1]]
#         else
#            pcvals <- (npcval(d, y, inAdjcovMat, adjmodel))[[1]]
#
#         if(rocmeth=="nonparametric") {   #rocmeth=nonparametric (default)
#            FPF_new <- 1-pcvals
#            cFPF_new <- ecdf(FPF_new)
#            TPF_new <- cFPF_new(FPF_new)
#            result <- min( FPF_new[which(TPF_new >= v)] )
#            return( ifelse( length(FPF_new)==0, 1, result ) )
#         }
#         else {                           #rocmeth=parametric
#            bnmatr <- getbnparm(1-pcvals)
#            if(link=="probit")
#               return( pnorm( (qnorm(v)-bnmatr[1,1])/bnmatr[1,2] ) )
#            else {
#               p <- ((log(1-v) - log(v))-bnmatr[1,1])/bnmatr[1,2]
#               return(exp(p)/(1+exp(p)))
#            }
#         }

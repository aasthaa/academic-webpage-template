

# Main function - Draw ROC curve(s) using placement values
roccurve <- function(dataset=NULL, d, markers, 
  rocmeth="nonparametric", link="probit", interval=c(0, 1, 10), ordinal=FALSE, 
  c_fpr=NULL, c_tpr=NULL,
  nograph=FALSE, bw=FALSE, roc=NULL, rocinv=NULL, offset=0.006,
  pvcmeth="empirical", tiecorr=FALSE, adjcov=NULL, adjmodel="stratified",
  nsamp=1000, noccsamp=FALSE, nostsamp=FALSE, cluster=NULL, 
  bsparam=TRUE, level=95, nobstrap=FALSE, titleOverride=NULL, dupStata=TRUE) {

  # Called by both pcval and npcval, when adjmodel="linear".
  # Returns percentile values, as well as the model fit
  getLinearPcvals <- function(d,y,adjcovMat,pcvmethod,bstrapRep) {

    pcvals <- vector(length=length(d[d==1]))
    mod <- NULL
    thresholds <- NULL

    n_db <- length(d[d==0])
    Y_db <- y[1:n_db]
    y_j <- y[(n_db+1):length(y)]

    ctrlsData <- as.data.frame(cbind(Y_db,adjcovMat[1:n_db,]))
    colnames(ctrlsData) <- c("Y_db", colnames(adjcovMat))
    formulaStr <- paste("Y_db ~", paste(colnames(adjcovMat), collapse="+"))
    mod <- glm(as.formula(formulaStr), data=ctrlsData)


    if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) ) {
      covariates <- unique(matrix(ctrlsData[,-1]))
      xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% t(covariates)
      mu_thresh <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

      thresholds <- matrix(nrow=dim(covariates)[1], ncol=length(adjcov)+1)
      thresholds[,2:(dim(thresholds)[2])] <- covariates
      colnames(thresholds) <- c("threshold",colnames(adjcovMat))
    }

    if(pcvmethod=="empirical") {
      xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% t(ctrlsData[,-1])
      mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

      resid <- Y_db-mu

      # Calculate CDF of y_j, P(Y_db <= y_j), under no parametric assumption
      F_le <- ecdf(sort(resid))

      xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                  t(adjcovMat[(n_db+1):length(y),])
      mu_D <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

      resid_D <- y_j - mu_D
      pcvals <- F_le(sort(resid_D))

      if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) ) {
        currThresh <- ifelse(!is.null(c_fpr), c_fpr, 
                             (calcRocinv(c_tpr,sort(pcvals)))[1])
        quant <- threshold( currThresh, resid )
        thresholds[,1] <- quant*sigma + mu_thresh
      }

    } else if(pcvmethod=="normal") {
      xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                  t(adjcovMat[(n_db+1):length(y),])
      mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

      sigma <- sd(mod$residuals)

      # Calculate CDF of y_j, P(Y_db <= y_j), under Normality assumption
      F_le <- pnorm((y_j-mu)/sigma)
      pcvals <- F_le

      if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) ) {
        currThresh <- ifelse(!is.null(c_fpr), c_fpr, 
                                 (calcRocinv(c_tpr,sort(pcvals)))[1])
        thresholds[,1] <- qnorm(p=1-currThresh)*sigma + mu_thresh
      }
    }

    if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) )
         thresholds <- thresholds[order(thresholds[,2]),]

    return(list(sort(pcvals), summary(mod), thresholds))
  }


  #Helper function to calculate threshold c correspdonding to c_fpr(f)
  threshold <- function(in_f, y_ctrl) {
    #y_ctrl <- in_y[which(d_vector==0)]
    if(pvcmeth=="empirical") {
      pcv <- pcval_calc(d=c(rep(0,length(y_ctrl)),rep(1,length(y_ctrl))), 
                        y=rep(y_ctrl,2), tiecorr)
      indices <- which((1-pcv) <= in_f)
      # If there are no placements values that are smaller than f, return largest y
      return( ifelse( length(indices)>0, min(y_ctrl[indices]), max(y_ctrl)))
    } else {
      mu <- mean(y_ctrl)
      sigma <- sd(y_ctrl)
      return( qnorm(p=1-in_f)*sigma + mu )
    }
  }



  #  THIS IS THE HIGHEST LEVEL percentile value FUNCTION
  # Calculate percentile values using empirical method
  # Calls pcval_calc for actual calculations
  getPcvals <- function(d, y, adjcovMat, adjmodel, tiecorr, bstrapRep) {
     
    pcvals <- vector(length=length(d[d==1]))
    mod <- NULL
    thresholds <- NULL

    # If adjusting for covariates, figure out stratified or linear
    if(!is.null(adjcovMat)) {

      if(adjmodel=="linear") {
        # Similar to what we do in parametric case,
        #    except now don't assume normal distn for residuals.
        # This is "semiparametric".
        if(pvcmeth=="empirical")
          return(getLinearPcvals(d,y,adjcovMat,"empirical",bstrapRep))
        else
          return(getLinearPcvals(d,y,adjcovMat,"normal",bstrapRep))

      } else if(adjmodel=="stratified") {
        stratas <- getStrata(d,y,adjcovMat)
        j <- 1
        if(!is.null(c_fpr) | !is.null(c_tpr))
          thresholds <- matrix(nrow=length(stratas), ncol=1+length(adjcov) )

        for(s in 1:length(stratas)) {
          #currStrata <- stratas[[s]]
          currD <- stratas[[s]][,1]
          currY <- stratas[[s]][,2]
          if(pvcmeth=="empirical")
            currPcvals <- pcval_calc(currD, currY, tiecorr)
          else
            currPcvals <- npcval_calc(currD, currY)
          pcvals[j:(j+length(currD[currD==1])-1)] <- currPcvals
          j <- j + length(currD[currD==1])

          if(!bstrapRep & !is.null(c_fpr)) {
            currThresh <- c_fpr
            thresholds[s,1] <- threshold(currThresh, currY[which(currD==0)] )
            strataVals <- sapply( 
                              as.vector(stratas[[s]][1,3:(dim(stratas[[s]])[2])]), 
                              function(x){return(as.numeric(x))} )
            thresholds[s,2:(dim(thresholds)[2])] <- strataVals
          }
        }

        if(!bstrapRep & !is.null(c_tpr)) {
          currThresh <- calcRocinv(c_tpr,sort(pcvals))
          for(s in 1:length(stratas)) {
            currStrata <- stratas[[s]]
            thresholds[s,1] <- threshold( currThresh, 
                                                currY[which(currD==0)] )
            strataVals <- sapply(as.vector(currStrata[1,3:(dim(currStrata)[2])]), 
                                 function(x){return(as.numeric(x))} )
            thresholds[s,2:(dim(thresholds)[2])] <- strataVals
          }
        }

        if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) ) {
          rownames(thresholds) <- seq(1:length(stratas))
          colnames(thresholds) <- c("threshold",
                                         colnames(currStrata)[3:dim(currStrata)[2]])
        }
      } # if (adjmodel == "stratified")

    } else {  # If not adjusting for covariates, the usual (entirely empirical) way
      
      if(pvcmeth=="empirical")
        pcvals <- pcval_calc(d,y,tiecorr)
      else
        pcvals <- npcval_calc(d,y)
      if(!bstrapRep & (!is.null(c_fpr) | !is.null(c_tpr)) ) {
        currThresh <- ifelse(!is.null(c_fpr), c_fpr, 
                                 (calcRocinv( c_tpr, sort(pcvals) ))[1])
        thresholds <- threshold(currThresh, y[which(d==0)])
      }
    }
    return(list(sort(pcvals), summary(mod), thresholds))
  }



  # Bootstrap CIs
  rocbsR <- function(i) {
    CImat <- vector(length=2)
    set.seed(51)
    thetahat.star <- replicate(nsamp, do.oneR(i))   # Bootstrap sampling
    bnmatr1.star <- bnmatr2.star <- NULL
    if(rocmeth=="parametric") {
      bnmatr1.star <- thetahat.star[2,]
      bnmatr2.star <- thetahat.star[3,]
      thetahat.star <- thetahat.star[1,]
    }
    #thetahat.star <- unlist(thetahat.star.lists[1,])
    alpha <- 1 - (level/100)
    CImat <- t(apply(matrix(thetahat.star), 2, 
                function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
    return( list(CImat, bnmatr1.star, bnmatr2.star) )
  }


  # function for executing the boostrap.  
  do.oneR <- function(i) {

    newAdjcovMat <- NULL
    if(adjust & adjmodel=="stratified" & nostsamp==FALSE) {
      stratas <- getStrata(d_vector,y[,i],adjcovMat)
      resample.ctrl <- NULL
      resample.case <- NULL
      resample.cohort <- NULL
      for(s in 1:length(stratas)) {
        resampIds <- as.numeric(rownames(stratas[[s]]))
        strataCluster <- clusterIDs[resampIds]
        resample <- getBstrapSample(stratas[[s]],noccsamp, cluster,
                                    clusterUniqueMat, cListFull[[s]], strataCluster)
        if(!noccsamp) {
          resample.ctrl <- c(resample.ctrl, resampIds[resample[[1]]])
          resample.case <- c(resample.case, resampIds[resample[[2]]])
        } else {
          resample.cohort <- c(resample.cohort, resampIds[resample])
        }
      }
    } else {
      resample <- getBstrapSample(dataset_ordered,noccsamp, cluster,
                                     clusterUniqueMat, cListFull)
      if(!noccsamp) {
        resample.ctrl <- resample[[1]]
        resample.case <- resample[[2]]
      } else {
        resample.cohort <- resample
      }
    }

    #We have the resampled indices. Put together the new dataset
    if(!noccsamp) {
      newdata <- data.frame(cbind( 
                     c(rep(0,length(resample.ctrl)),rep(1,length(resample.case))), 
                     c(y[resample.ctrl,i],y[resample.case,i]) ))
      if(adjust) {
        if(1==length(adjcov)) {
          newAdjcovMat <- as.data.frame(c(adjcovMat[resample.ctrl,],
                                        adjcovMat[resample.case,]))
        } else {
          newAdjcovMat <- as.data.frame(rbind(adjcovMat[resample.ctrl,],
                                        adjcovMat[resample.case,]))
        }
        colnames(newAdjcovMat) <- adjcov
      }

    } else {
      newdata <- data.frame(cbind((dataset_ordered$d)[resample.cohort], 
                            y[resample.cohort,i] ))
      if(adjust) {
        newAdjcovMat <- as.data.frame(adjcovMat[resample.cohort,])
        colnames(newAdjcovMat) <- adjcov
        #    newdata <- cbind( newdata, newAdjcovMat )
      }
      orderD <- order(newdata$d)
      newdata <- newdata[orderD,]
      newAdjcovMat <- newAdjcovMat[orderD,]
    }

    colnames(newdata) <- c("d", "y")

    # Generate new percentile values
 #   if(pvcmeth=="empirical") {
      newPcvals <- (getPcvals(newdata$d, newdata$y, newAdjcovMat, 
                       adjmodel, tiecorr, bstrapRep=TRUE))[[1]]
 #   } else {
 #     newPcvals <- (getPcvals(newdata$d, newdata$y, newAdjcovMat, 
 #                      adjmodel, tiecorr, bstrapRep=TRUE))[[1]]
 #   }

    # Calculate statistic based on new percentile values
    if(!is.null(roc)) {
      return(roct(newPcvals))
    } else if(!is.null(rocinv))
      return(calcRocinv(rocinv, newPcvals))
  }


  # Get ROC value at given t (and fit the binormal model if rocmeth=="parametric")
  roct <- function(in_pcvals) {

    if(rocmeth=="nonparametric") {
      F_pl <- ecdf(1-in_pcvals)
      return( F_pl(t) )

    } else {
      bnmatr <- getbnparm(1-in_pcvals)
      if(link=="probit")
        return( c(pnorm(bnmatr[1,1] + bnmatr[1,2]*qnorm(t)), bnmatr) )
      else {
        p <- bnmatr[1,1] + bnmatr[1,2]*(log(1-t) - log(t))
        return( c(exp(p)/(1+exp(p)), bnmatr[1,1], bnmatr[1,2]))
      }
    }

  }


  # Get parameter estimates for binormal ROC curve when the rocmeth=parametric 
  #    option is specified.  Link = probit or logit... as specified in the function
  #    arguments.
  getbnparm <- function(in_plvals) {

    k <- seq(length=np, from=1, to=np)
    f <- (a + (b-a)*k)/(np+1)

    if(!ordinal) {
      if(link=="probit")
        q <- qnorm(f)
      else
        q <- log(1-f) - log(f)

      in_plvals  # WHAT IS THIS  (why are we outputing it)?
      x <- rep(q, length(in_plvals))

      expandedPlVals <- matrix(apply(matrix(in_plvals), 1, function(x) {rep(x,np)}), 
                               nrow=np*(length(in_plvals)), ncol=1, byrow=TRUE )
      expandedF <- rep(f, length(in_plvals))
      u <- matrix( as.numeric(expandedPlVals <= expandedF), 
                  nrow=np*length(in_plvals), ncol=1)

      if(link=="probit")
        regrModel <- glm(u ~ x, family=binomial(probit))
      else
        regrModel <- glm(u ~ x, family=binomial(logit))
    } else {


    }
    bnmatr      <- matrix(nrow=1, ncol=2)
    bnmatr[1,1] <- regrModel$coeff[1]
    bnmatr[1,2] <- regrModel$coeff[2]

    return(bnmatr)
  }


  # Get inverse of ROC function, at a given TPF=v
  calcRocinv <- function(v, in_pcvals) {
    if(rocmeth=="nonparametric") {
      FPF_new <- 1-in_pcvals
      cFPF_new <- ecdf(FPF_new)
      TPF_new <- cFPF_new(FPF_new)
      result <- min( FPF_new[which(TPF_new >= v)] )
      return( ifelse( length(FPF_new)==0, 1, result ) )
    } else {
      bnmatr <- getbnparm(1-in_pcvals)
      if(link=="probit")
        return( c(pnorm( (qnorm(v)-bnmatr[1,1])/bnmatr[1,2] ), 
               bnmatr[1,1], bnmatr[1,2]) )
      else {
        p <- ((log(1-v) - log(v))-bnmatr[1,1])/bnmatr[1,2]
        return( c(exp(p)/(1+exp(p)), bnmatr[1,1], bnmatr[1,2]) )
      }
    }
  }


  checkErrorsRoccurve <- function() {
    if(length(unique(d_vector))!=2) cat("d must take on two values\n")
    else if(min(d_vector)!=0 | max(d_vector)!=1) cat("d must be 0/1\n")
    else if(is.null(y[,1])) cat(paste(markers[1],"must contain values\n"))
    else if(!(pvcmeth=="empirical"|pvcmeth=="normal"))
      cat("pvcmeth option must be either empirical or normal if specified\n")
    else if(!(rocmeth=="nonparametric"|rocmeth=="parametric"))
      cat("rocmeth option must be either parametric or nonparametric if specified\n")
# NOT NECESSARY, BUT bsparam is ignored if rocmeth != "parametric"
#   else if(rocmeth=="nonparametric" & bsparam==TRUE)
#     cat("bsparam option not allowed when rocmeth=nonparametric\n")
    else if(!(link=="probit"|link=="logit"))
      cat("link option must be either probit or logit if specified\n")

    # Check roc() and rocinv() syntax
    else if(!is.null(roc) && !is.null(rocinv))
      cat("only one of roc(f) and rocinv(t) options can be specified\n")
    else if( !is.null(roc) && (!(roc>0 & roc<1) | !is.numeric(roc)) )
      cat("argument for roc option must be between 0 & 1\n")
    else if( !is.null(rocinv) && (!(rocinv>0 & rocinv<1) | !is.numeric(rocinv)) )
      cat("argument for rocinv option must be between 0 & 1\n")

    # Check sampling variability options
    else if((!is.null(roc)|!is.null(rocinv)) & !(offset>=0 & offset<=0.02))
      cat("offset argument must be between 0 & 0.02, if specified\n")
    else if(!is.numeric(nsamp) | (nsamp<1 & nsamp!=0))
      cat("nsamp argument must be >1\n")

    # Check interval() option arguments
    else if(!(interval[1]>=0 & interval[1]<=1 & interval[2]>=0 & interval[2]<=1))
      cat("first two interval arguments, a & b, must be between 0 & 1\n")
    else if(interval[2] <= interval[1]) cat("interval arguments must satisfy a < b\n")
    else if(!((interval[3]/as.integer(interval[3]))==1 & interval[3]>0))
      cat("3rd interval argument, np, must be a positive integer\n")

    # Check covariate adjustment options
    else if(!(adjmodel=="stratified"|adjmodel=="linear"))
      cat("adjmodel option must be either linear or stratified if specified\n")
    else if(!is.null(adjcov) & adjmodel=="stratified" & 
            isStrataCtrlLow(d_vector,adjcovMat,2)) 
      cat("fewer than 2 controls in some case-containing strata defined ",
          "by stratification variable adjcov.  Need to redefine/broaden ",
          "adjustment strata specified by adjcov\n")

      # Threshold options
#    else if( !is.null(c_fpr) && !is.null(c_tpr) )
#      cat("only one of c_fpr(f) or c_tpr(t) options can be specified\n")
    else if( !is.null(c_fpr) && !(c_fpr>0 & c_fpr<1) )
      cat("argument for c_fpr option must be between 0 & 1, if specified\n")
    else if( !is.null(c_tpr) && !(c_tpr>0 & c_tpr<1) )
      cat("argument for c_tpr option must be between 0 & 1, if specified\n")
    else if( ordinal & !is.null(c_fpr) )
      cat("c_fpr(f) option cannot be specified with ordinal option\n")
    else if( ordinal & !is.null(c_tpr) )
      cat("c_tpr(t) option cannot be specified with ordinal option\n")


    # Not in Stata code. My own additions
    else if(!(ordinal==TRUE | ordinal==FALSE))
      cat("ordinal option must be TRUE or FALSE, if specified\n")

    else if(!(nograph==TRUE | nograph==FALSE)) 
      cat("nograph option must be TRUE or FALSE, if specified\n")
    else if(!(bw==TRUE | bw==FALSE))
      cat("bw option must be TRUE or FALSE, if specified\n")
    else if(!(tiecorr==TRUE | tiecorr==FALSE))
      cat("tiecorr option must be TRUE or FALSE, if specified\n")
    else if(!(noccsamp==TRUE | noccsamp==FALSE))
      cat("noccsamp option must be TRUE or FALSE, if specified\n")
    else if(!(nostsamp==TRUE | nostsamp==FALSE))
      cat("nostsamp option must be TRUE or FALSE, if specified\n")
    else if(!(bsparam==TRUE | bsparam==FALSE))
      cat("bsparam option must be TRUE or FALSE, if specified\n")
    else if(!(level>0 & level<100))
      cat("level option must be between 0 & 100, if specified\n")
    else if(!(nobstrap==TRUE | nobstrap==FALSE))
      cat("nobstrap option must be TRUE or FALSE, if specified\n")

    else return(FALSE)
    return(TRUE)
  }

   ### END OF HELPER FUNCTIONS DEFINITIONS




  # Assign general variables
  nmark <- length(markers)
  if(link=="") link <- "probit"
  if(pvcmeth=="") pvcmeth <- "empirical"
  if(rocmeth=="") rocmeth <- "nonparametric"
  if(nsamp==0) nobstrap <- TRUE
  a <- interval[1]
  b <- interval[2]
  np <- interval[3] 
  t <- roc
  adjust <- ifelse(!is.null(adjcov), TRUE, FALSE)
  nStrata <- 1

  resultList <- NULL   # Store results to return
  resultList <- list()
  #names(resultList) <- NULL

  ########################
  #Do error checking and create working dataset
  #If dataset variable is specified
  if(!is.null(dataset)) {
    # Check that specified dataset is valid
    if(!exists(dataset))
      stop("Specified dataset does not exist\n")

    # Check that specified disease marker is valid
    if(!(d %in% names(eval(parse(text=dataset)))) )
      stop("Specified disease marker does not exist\n")

    # Check that specified marker vectors specified are valid
    if(sum(markers %in% names(eval(parse(text=dataset))))<length(markers) ) 
      stop("At least one of the specified test markers does not exist\n")

    # Disease and test markers exist - start creating working dataset
    working_dataset <- as.data.frame(eval(parse(text=paste(dataset,"$",d,sep=""))))

    for(i in 1:nmark)
      working_dataset <- cbind(working_dataset, 
                               eval(parse(text=paste(dataset,"$",markers[i],sep=""))))

    # Check that specified adjcov markers specified are valid. If so, 
    #   add to working dataset
    if(!is.null(adjcov)) {
      if(sum(adjcov %in% names(eval(parse(text=dataset))))<length(adjcov) ) 
            stop("At least one of the specified adjcov markers does not exist\n")
      else {
        for(i in 1:length(adjcov))
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(dataset,"$",adjcov[i],sep=""))))
      }
    }
    # Check that specified cluster variables are valid. If so, add to working dataset
    if(!is.null(cluster)) {
      if(sum(cluster %in% names(eval(parse(text=dataset))))<length(cluster) ) 
            stop("At least one of the specified cluster variables does not exist\n")
      else {
        for(i in 1:length(cluster))
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(dataset,"$",cluster[i],sep=""))))
      }
    }
    colnames(working_dataset) <- c(d,markers,adjcov,cluster)

  } else {   #If dataset variable is not specified

    working_dataset_colnames <- NULL
    # Check that specified disease marker is valid
    splitVar <- strsplit(d,"$",fixed=TRUE)
    if(length(splitVar[[1]]) == 1) {
      if(!exists(d)) stop("Specified disease marker does not exist\n")
      working_dataset_colnames <- d
      working_dataset <- as.data.frame(eval(parse(text=d)))
    } else {
      if(!((splitVar[[1]])[2] %in% names(eval(parse(text=(splitVar[[1]])[1])))) )
            stop("Specified disease marker does not exist\n")
      working_dataset_colnames <- (splitVar[[1]])[2]
      working_dataset <- as.data.frame(eval(parse(text=d)))
      d <- (splitVar[[1]])[2]
    } 

    # Check that specified marker vectors specified are valid
    splitVar <- strsplit(markers,"$",fixed=TRUE)
    for(i in 1:length(markers)) {
      if(length(splitVar[[i]]) == 1) {
        if(!exists(markers[i]))
               stop("At least one of the specified test markers does not exist\n")
        working_dataset_colnames <- c(working_dataset_colnames, markers[i])
        working_dataset <- cbind(working_dataset, 
                                 eval(parse(text=paste(markers[i],sep=""))))
      } else {
        if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))))
               stop("At least one of the specified test markers does not exist\n")
        working_dataset_colnames <- c( working_dataset_colnames, (splitVar[[i]])[2])
        working_dataset <- cbind(working_dataset, 
                                 eval(parse(text=paste(markers[i],sep=""))))
        markers[i] <- (splitVar[[i]])[2]
      }
    }

    # Check that specified adjcov markers specified are valid
    if(!is.null(adjcov)) {
      splitVar <- strsplit(adjcov,"$",fixed=TRUE)
      for(i in 1:length(adjcov)) {
        if(length(splitVar[[i]]) == 1) {
          if(!exists(adjcov[i]))
             stop("At least one of the specified adjcov variables does not exist\n")
          working_dataset_colnames <- c(working_dataset_colnames, adjcov[i])
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(adjcov[i],sep=""))))
        } else {
          if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))))
             stop("At least one of the specified adjcov variables does not exist\n")
          working_dataset_colnames <- c( working_dataset_colnames, (splitVar[[i]])[2] )
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(adjcov[i],sep=""))))
          adjcov[i] <- (splitVar[[i]])[2]
        } 
      }
    }

    # Check that specified cluster variables are valid
    if(!is.null(cluster)) {
      splitVar <- strsplit(cluster,"$",fixed=TRUE)
      for(i in 1:length(cluster)) {
        if(length(splitVar[[i]]) == 1) {
          if(!exists(cluster[i]))
             stop("At least one of the specified cluster variables does not exist\n")
          working_dataset_colnames <- c(working_dataset_colnames, cluster[i])
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(cluster[i],sep=""))))
        } else {
          if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
             stop("At least one of the specified cluster variables does not exist\n")
          working_dataset_colnames <- c(working_dataset_colnames, (splitVar[[i]])[2])
          working_dataset <- cbind(working_dataset, 
                                   eval(parse(text=paste(cluster[i],sep=""))))
          cluster[i] <- (splitVar[[i]])[2]
        }
      }
    }
    colnames(working_dataset) <- working_dataset_colnames
  }


  #Order dataset by disease status, to give final working dataset
  dataset_ordered <- working_dataset[order(eval(parse(
                                      text=paste("working_dataset$",d,sep="")))),]

  #### First round of error checking done. Working dataset created.
  missingDataRows <- (which(is.na(dataset_ordered), arr.ind=TRUE))[,1]
  if(length(missingDataRows)>0) 
    dataset_ordered <- dataset_ordered[-missingDataRows,]

##### Fix after checking what dataset_ordered column names are
#   if(is.null(dataset))
#      d_vector <- eval(parse(text=paste("dataset_ordered$","d",sep="")))
#   else
      d_vector <- eval(parse(text=paste("dataset_ordered$",d,sep="")))

  y <- matrix(nrow=(dim(dataset_ordered))[1], ncol=nmark)
  for(i in 1:nmark)
    y[,i] <- eval(parse(text=paste("dataset_ordered","$",markers[i],sep="")))

  adjcovMat <- NULL
  if(adjust) {
    adjcovMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(adjcov))
    for(i in 1:length(adjcov))
      adjcovMat[,i] <- eval(parse(text=paste("dataset_ordered","$",adjcov[i],sep="")))
    adjcovMat <- data.frame(adjcovMat)
    colnames(adjcovMat) <- adjcov
  }


  clusterMat <- NULL
  clusterUniqueMat <- NULL
  clusterIDs <- vector(length=(dim(dataset_ordered)[1]))
  if(!is.null(cluster)) {
    clusterMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(cluster))
    for(i in 1:length(cluster))
      clusterMat[,i] <- eval(parse(text=
                              paste("dataset_ordered","$",cluster[i],sep="")))
    clusterMat <- data.frame(clusterMat)
    colnames(clusterMat) <- cluster
    clusterUniqueMat <- unique(as.data.frame(cbind(d_vector,clusterMat)))
    colnames(clusterUniqueMat) <- c(d,cluster)
    for(s in 1:(dim(clusterUniqueMat)[1])) {
      currCluster <- as.data.frame(cbind(d_vector, clusterMat, 
                                      seq(1:(dim(dataset_ordered)[1]))))
      colnames(currCluster) <- c(d,cluster,"origDatasetID")

      for(k in 1:length(cluster)) {
        currCluster <- currCluster[which(as.numeric(eval(parse(
                            text=paste("currCluster$",cluster[k],sep="")))) == 
                            clusterUniqueMat[s,k+1]),]
      }
      currCluster <- currCluster[which(
                         eval(parse(text=paste("currCluster$",d,sep=""))) == 
                         eval(parse(text=paste("clusterUniqueMat$",d,sep="")))[s]),]
      clusterIDs[currCluster$origDatasetID] <- s
    }
  }
   
  # calculate cluster lists
  if(!is.null(cluster)) { 
    if(adjust & adjmodel=="stratified" & nostsamp==FALSE) {
      cListFull <- list()
      stratas <- getStrata(d_vector,y[,i],adjcovMat)
      for(s in 1:length(stratas)) {
        resampIds <- as.numeric(rownames(stratas[[s]]))
        cListFull[[s]] <- makeClist(clusterIDs[resampIds])
      }
    } else {
      cListFull <- makeClist(clusterIDs)
    }
  }

  ###############
  # MODEL FITTING AND TERMINAL OUTPUT STARTS HERE
  # Proceed if no more errors in variables
  isError <- checkErrorsRoccurve()
  
  if(!isError) {

    if(adjust & adjmodel=="stratified" & isStrataCtrlLow(d_vector,adjcovMat,10)) {
         cat("Warning: fewer than 10 controls in some case-containing strata 
             defined by stratification variable adjcov\n")
    }

    #############
    #############
    # Calculate placement/percentile values
    pcvalResults <- vector("list",length=3)
    pcvals <- matrix(nrow=nmark, ncol=length(d_vector[d_vector==1]), byrow=TRUE)
    # if(adjust & adjmodel=="linear")
    linModels <- vector("list",length=nmark)

    # If c_tpr or c_fpr option specified for thresholds, 
    #     create appropriate data structures
    if(!is.null(c_fpr) | !is.null(c_tpr)) {
      if(!adjust) {
        C <- matrix(nrow=nmark, ncol=1, dimnames=
                    list(markers, ifelse(!is.null(c_fpr), "c_fpr","c_tpr")))
      } else {
        C <- vector("list")
      }
    }


 #   if(pvcmeth=="empirical") {
      for(i in 1:nmark) {
        pcvalResults <- getPcvals(d=d_vector, y=y[,i], adjcovMat, adjmodel, 
                                  tiecorr, bstrapRep=FALSE) 
        pcvals[i,] <- pcvalResults[[1]]
        linModels[[i]] <- pcvalResults[[2]]
        if(!is.null(c_fpr) | !is.null(c_tpr)) {
          if(!adjust)
            C[i] <- pcvalResults[[3]]
          else
            eval(parse(text=paste("C$",markers[i],"<-pcvalResults[[3]]",sep="")))
        }
      }
 
  # DEM Aug. 5 2010,  Don't see any difference in the 2 parts of the if-then-else.
  #    (above and below).  Didn't remove in case I'm just overlooking the diff.

  #  } else {
  #    for(i in 1:nmark) {
  #      pcvalResults <- getPcvals(d=d_vector, y=y[,i], adjcovMat, adjmodel, 
  #                                tiecorr, bstrapRep=FALSE)
  #      pcvals[i,] <- pcvalResults[[1]]
  #      linModels[[i]] <- pcvalResults[[2]]
  #      if(!is.null(c_fpr) | !is.null(c_tpr)) {
  #        if(!adjust)
  #          C[i] <- pcvalResults[[3]]
  #        else
  #          eval(parse(text=paste("C$",markers[i],"<-pcvalResults[[3]]",sep="")))
  #      }
  #    } # for loop
  #  } # else 


    # If c_tpr or c_fpr option specified, add results to resultList
    if(!is.null(c_fpr) | !is.null(c_tpr)) {
      resultList <- list(C)
      names(resultList) <- ifelse(adjust, "C", "c")
    }


    # Generate placement values
    plvals <- 1-pcvals

    ###############
    ###############
    # Output specified options
    cat( paste("ROC calculation for markers:", paste(markers, collapse=", "), "\n"))

    outOpts_rocmeth <- NULL
    outOpts_rocmeth <- rbind(outOpts_rocmeth, ifelse(rocmeth=="nonparametric", 
                             "non-parametric (Empirical ROC)", "parametric"))
    rownames(outOpts_rocmeth) <- "ROC method:"
    colnames(outOpts_rocmeth) <- ""
    print(outOpts_rocmeth, quote=FALSE)

    outOpts_rocparam <- NULL
    if(rocmeth=="parametric") {
      outOpts_rocparam <- rbind(outOpts_rocparam, 
            ifelse(link=="probit", "probit - binormal ROC", "logit - bilogistic ROC"))
      outOpts_rocparam <- rbind(outOpts_rocparam, np)
      outOpts_rocparam <- rbind(outOpts_rocparam, paste("(", a, ",", b, ")", sep=""))
      rownames(outOpts_rocparam) <- c("link function:", "number of points:", 
                                      "on FPR interval:")
      colnames(outOpts_rocparam) <- ""
      cat("\nGLM fit")
      print(outOpts_rocparam, quote=FALSE)
    }

    outOpts_pvcmeth <- NULL
    outOpts_pvcmeth <- rbind(outOpts_pvcmeth, pvcmeth)
    if(pvcmeth=="empirical") {
      outOpts_pvcmeth <- rbind(outOpts_pvcmeth, ifelse(tiecorr==FALSE, "no", "yes"))
      rownames(outOpts_pvcmeth) <- c("method:", "tie correction:")
    } else
      rownames(outOpts_pvcmeth) <- "method:"
    colnames(outOpts_pvcmeth) <- ""
    cat("\nPercentile value calculation")
    print(outOpts_pvcmeth, quote=FALSE)

    ###############
    ###############
    # Output model fit information about covariate adjustments
    if(adjust) {
      outOpts_covAdj <- ifelse(adjmodel=="stratified", "stratified", "linear model")
      outOpts_covAdj <- rbind(outOpts_covAdj, paste(adjcov, collapse=", "))
      rownames(outOpts_covAdj) <- c("method:", "covariates:")
      colnames(outOpts_covAdj) <- ""
      cat("\nCovariate adjustment")
      print(outOpts_covAdj, quote=FALSE)

      if(adjmodel=="stratified") {
        stratas <- getStrata(d_vector,y[,1],adjcovMat)
        dCount <- matrix(nrow=length(stratas),ncol=2)
        for(s in 1:length(stratas)) {
          currStrata <- stratas[[s]]

          dCount[s,1] <- length(which(currStrata[,1]==0))
          dCount[s,2] <- length(which(currStrata[,1]==1))
        }
        dCount <- cbind(seq(1:length(stratas)), dCount, dCount[,1]+dCount[,2])
        colnames(dCount) <- c("Stratum",paste(d,"=0",sep=""),
                              paste(d,"=1",sep=""),"Total")
        rownames(dCount) <- rep("",dim(dCount)[1])
        dCount <- rbind(dCount, c("Total", sum(dCount[,2]),
                        sum(dCount[,3]), sum(dCount[,4])))
        cat(paste("# of case-containing strata:",length(stratas),"\n\n"))
        print(dCount, quote=FALSE)
      } else {
        for(i in 1:nmark) {
          cat("\n\n************\n\n")
          cat("Covariate adjustment - linear model, controls only\n")
          cat( paste("Model results for marker:",markers[i],"\n") )
          print(linModels[[i]])
        }
      }
    }


    ###############
    ############### 
    # If roc or rocinv specified, calculate the ROC model and print output
    if(!is.null(roc) | !is.null(rocinv)) {
      rocVals <- vector(length=nmark)

      if(rocmeth=="parametric") {
        BNParm <- matrix(nrow=nmark,ncol=2,
                         dimnames=list(markers,c("alpha_0","alpha_1")))
        if(bsparam) {
          BNP_se <- matrix(nrow=nmark,ncol=2,
                           dimnames=list(markers, c("se_alpha_0","se_alpha_1")))
          BNP_ci <- matrix(nrow=nmark,ncol=4,
                           dimnames=list(markers,c("alpha_0 LB","alpha_0 UB",
                           "alpha_1 LB","alpha_1 UB")))
        }
      }

      CImat <- matrix(nrow=nmark, ncol=2, byrow=TRUE)
      output <- NULL
      estimateList <- NULL

      for(i in 1:nmark) {
        if(!nobstrap) {
          CIList <- rocbsR(i=i)
          CImat[i,] <- signif(CIList[[1]],3)
          if(rocmeth=="parametric" & bsparam) {
            # Assign values to BNP_se to return
            BNP_se[i,1] <- sd(CIList[[2]])
            BNP_se[i,2] <- sd(CIList[[3]])
            # Assign values to BNP_ci to return
            alpha <- 1 - (level/100)
            BNP_ci[i,1:2] <- t(apply(matrix(CIList[[2]]), 2, 
                               function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
            BNP_ci[i,3:4] <- t(apply(matrix(CIList[[3]]), 2, 
                               function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
          }
        }
        if(!is.null(roc))
          estimateList <- roct(pcvals[i,])
        else if(!is.null(rocinv))
          estimateList <- calcRocinv(rocinv, pcvals[i,])
        rocVals[i] <- signif(estimateList[1], 3)
        if(rocmeth=="parametric")
          BNParm[i,] <- c(estimateList[2], estimateList[3])
        output <- rbind(output, c(markers[i], rocVals[i], 
        paste("(",CImat[i,1],", ",CImat[i,2],")", sep="")))
      }


    # Set up resultList - list of values to return
      ROC_ci <- cbind(rocVals, CImat)
      rownames(ROC_ci) <- markers
      if(!is.null(roc)) {
        colnames(ROC_ci) <- c(paste("ROC(", t, ")", sep=""), 
                              "Lower Bound", "Upper Bound")
      } else if(!is.null(rocinv)) {
        colnames(ROC_ci) <- c(paste("ROC^(-1)(", rocinv, ")", sep=""), 
                              "Lower Bound", "Upper Bound")
      }
      resultList$ROC_ci <- ROC_ci

      if(rocmeth=="parametric") {
        resultList$BNParm <- BNParm
        if(bsparam) {
          resultList$BNP_se <- BNP_se
          resultList$BNP_ci <- BNP_ci
        }
      }


      rownames(output) <- rep("", nmark)
      if(!is.null(roc)) {
        colnames(output) <- c("Marker", paste("ROC @ f=", t, sep=""), 
                              paste(level, "% Confidence Interval", sep=""))
      } else if(!is.null(rocinv)) {
        colnames(output) <- c("Marker", paste("ROC^(-1) @ t=", rocinv, sep=""), 
                              paste(level, "% Confidence Interval", sep=""))
      }

      cat("\n\n************\n\n")
      print(format(output, justify="left"), quote=FALSE)


      #Sampling options
      cat("\nbootstrap percentile CI's based on sampling\n")
      sampDesign <- ifelse(noccsamp==FALSE, "separately from cases and controls\n", 
                          "w/o respect to case/control status\n")
      cat(sampDesign)
      if(adjust & adjmodel=="stratified")
        cat("and from within covariate strata\n")

      cat( paste("\nbootstrap samples:",nsamp,"\n") )
    }


    ##############
    ##############
    # Draw ROC curve(s)
    if(!nograph) {
      F_pl <- ecdf(plvals[1,])

      #pdf(filename)
      if(dupStata) par(plt=c(0.15, 0.65, 0.25, 0.75), xpd=FALSE)
      if(dupStata) plot.new()
      plot(c(1,F_pl(plvals[1,]),0) ~ c(1,plvals[1,],0), 
           type="n", xlim=c(0,1), ylim=c(0,1),
           xlab="FPF", ylab="TPF", cex.lab=1.5, frame.plot=TRUE, axes=FALSE)
      axis(1, at=c(0,1))
      axis(2, at=c(0,1))
      abline(h=seq(0,1,0.2), v=seq(0,1,0.2), col="lightgray", lty="solid", 
           lwd=par("lwd"))
      abline(0, 1, col=8)
      titleString <- paste("markers: ", paste(markers,collapse=", "))
      colString <- NULL
      ltyString <- NULL

      if(rocmeth=="nonparametric") {
        tprLocal <- matrix(nrow=nmark, ncol=length(d_vector[d_vector==1])+2, 
                           byrow=TRUE)
        fprLocal <- matrix(nrow=nmark, ncol=length(d_vector[d_vector==1])+2, 
                           byrow=TRUE)
      } else {
        f <- seq(from=a+0.000001, to=b-0.000001, by=0.001)
        tprLocal <- matrix(nrow=nmark, ncol=length(f), byrow=TRUE)
        fprLocal <- matrix(nrow=nmark, ncol=length(f), byrow=TRUE)
      }

      # plot each marker one by one
      for(i in 1:nmark) {

        F_pl <- ecdf(plvals[i,])

        currCol <- ifelse(bw==FALSE, i, "black")
        if(i == 1)   currCol <- ifelse(bw==FALSE, "green4", "black")
        else if(i == 2)   currCol <- ifelse(bw==FALSE, "orange", "black")

        colString <- c(colString, currCol)

        currlty <- ifelse(bw==FALSE, 1, i)
        ltyString <- c(ltyString, currlty)

        if(rocmeth=="nonparametric") {
          # Generate tpr and fpr values
          tprLocal[i,] <- c(1,F_pl(plvals[i,]),0)
          fprLocal[i,] <- c(1,plvals[i,],0)
          # Draw plot
          lines(tprLocal[i,] ~ fprLocal[i,], type="S", lwd=2, 
                lty=currlty, col=currCol)
        } else {
          # Generate tpr and fpr values
          bnmatr <- getbnparm(plvals[i,])
          if(link=="probit")
            rocf <- pnorm(bnmatr[1,1] + bnmatr[1,2]*qnorm(f))
          else {
            p <- bnmatr[1,1] + bnmatr[1,2]*(log(1-f) - log(f))
            rocf <- exp(p)/(1+exp(p))
          }
          tprLocal[i,] <- rocf
          fprLocal[i,] <- f
          # Draw plot
          lines(tprLocal[i,] ~ fprLocal[i,], lwd=2, lty=currlty, col=currCol)
        }
        par(lend="butt")
        tOff <- t + (i-1)*offset
        vOff <- rocinv + (i-1)*offset
        if(!is.null(roc)) {
          points(tOff, rocVals[i], pch=20, col="gray40")
          lines(x=rep(tOff,2), y=CImat[i,], col="gray40")
          lines(x=c(tOff-0.01,tOff+0.01), y=rep(CImat[i,1],2), col="gray40")
          lines(x=c(tOff-0.01,tOff+0.01), y=rep(CImat[i,2],2), col="gray40")
        } else if(!is.null(rocinv)) {
          points(rocVals[i], vOff, pch=20, col="gray40")
          lines(x=CImat[i,], y=rep(vOff,2), col="gray40")
          lines(x=rep(CImat[i,1],2), c(vOff-0.01,vOff+0.01), col="gray40")
          lines(x=rep(CImat[i,2],2), c(vOff-0.01,vOff+0.01), col="gray40")
        }
        if(dupStata) par(xpd=TRUE)
      } # for loop on markers

      if(is.null(titleOverride)) {
        title(titleString, cex.main=1.5)
      } else {
        title(titleOverride,cex.main=1.5)
      }

      if(dupStata) {
        legend(x=1.15, y=0.6, legend=markers, col=colString, bty="n",
               lwd=rep(2,nmark), lty=ltyString,  title="marker", cex=1.10)
      } else {
        legend(x=.6, y=0.6, legend=markers, col=colString, bty="n",
               lwd=rep(2,nmark), lty=ltyString,  title="marker", cex=.9)
      }
      #dev.off()
                
      resultList$tpf <- tprLocal
      resultList$fpf <- fprLocal

    }

    invisible(resultList)

  } # if no error
}



### in getLinearPcvals, check use of sigma versus sigma_D, when calculating distribution
###   of y_j.
### numbers seem right doing it the way it is, i.e. using sigma, not sigma_D
### check what the correct method is


# Main function - Do ROC regression
rocreg <- function(dataset=NULL, d, markers, regcov=NULL, sregcov=NULL, 
   link="probit", 
   interval=c(0, 1, 10), ordinal=FALSE, pvcmeth="empirical", tiecorr=FALSE, 
   adjcov=NULL, adjmodel="stratified", nsamp=1000, nobstrap=FALSE, 
   noccsamp=FALSE, nostsamp=FALSE, cluster=NULL, resfile=NULL, 
   replace=FALSE, level=95) {


   ### DEFINE HELPER FUNCTIONS


   # Called by both pcval and npcval, when adjmodel="linear"
   # Returns percentile values, as well as the model fit
   getLinearPcvals <- function(d,y,adjcovMat,pcvmethod) {
      pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      n_db <- length(d[d==0])
      Y_db <- y[1:n_db]
      y_j <- y[(n_db+1):length(y)]

      ctrlsData <- as.data.frame(cbind(Y_db,adjcovMat[1:n_db,]))
      colnames(ctrlsData) <- c("Y_db", colnames(adjcovMat))
      formulaStr <- paste("Y_db ~", paste(colnames(adjcovMat), collapse="+"))
      mod <- glm(as.formula(formulaStr), data=ctrlsData)

      #sigma <- sd(Y_db)

    #  mu <- mod$coeff[1] + mod$coeff[2:length(mod$coeff)] %*% 
    #             t(adjcovMat[(n_db+1):length(y)])
    #  mu <- mod$coeff[1] + mod$coeff[2:length(mod$coeff)] %*% t(pcvData[,-1])
    #  sigma <- sd(Y_db)

      if(pcvmethod=="empirical") {
         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% t(ctrlsData[,-1])
         mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

       #  resid <- (Y_db-mu)/sigma
         resid <- Y_db-mu
         # Calculate CDF of y_j, P(Y_db <= y_j), under no parametric assumption
         F_le <- ecdf(sort(resid))

         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                  t(adjcovMat[(n_db+1):length(y),])
         mu_D <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

      #sigma_D <- sd(y_j)

        # resid_D <- (y_j - mu_D)/sigma
         resid_D <- y_j - mu_D
      #resid_D <- (y_j - mu_D)/sigma_D
         pcvals <- F_le(resid_D)   #F_le(sort(resid_D))
      } else if(pcvmethod=="normal") {
     
         sigma <- sd(mod$residuals)

         xbeta <- t(matrix(mod$coeff[2:length(mod$coeff)])) %*% 
                           t(adjcovMat[(n_db+1):length(y),])
         mu <- mod$coeff[1] + apply(xbeta,2,function(x) sum(x))

         # Calculate CDF of y_j, P(Y_db <= y_j), under Normality assumption
         F_le <- pnorm((y_j - mu)/sigma)
         pcvals <- F_le
      }
      return(list(pcvals, summary(mod)))
   }


   # Calculate percentile values using empirical method
   # Calls pcval_calc for actual calculations
   pcval <- function(d, y, adjcovMat, adjmodel, tiecorr) {
     # pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      # If adjusting for covariates, figure out stratified or linear
      if(!is.null(adjcovMat)) {
         pcvals <- vector(length=length(d))
         if(adjmodel=="linear") {
            # Similar to what we do in parametric case,
            # except now don't assume normal distn for residuals
            # This is "semiparametric"
            return(getLinearPcvals(d,y,adjcovMat,"empirical"))
         } else if(adjmodel=="stratified") {
            stratas <- getStrata(d,y,adjcovMat)
            j <- 1
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
        #       colnames(currStrata) <- c("d","y",colnames(adjcovMat))
               currD <- currStrata[,1]
               currY <- currStrata[,2]
               resampIds <- as.numeric(rownames(currStrata))
               resampCases <- resampIds[which(currD==1)]
        #       pcvals[j:(j+length(currD[currD==1])-1)] <- 
        #                  pcval_calc(currD, currY, tiecorr)
        #       j <- j + length(currD[currD==1])
               pcvals[resampCases] <- pcval_calc(currD, currY, tiecorr)
            }
         }
         pcvals <- pcvals[which(d==1)]
      } else {
         # If not adjusting for covariates, the usual (entirely empirical) way
         pcvals <- pcval_calc(d,y,tiecorr)
      }
 
      return(list(pcvals, summary(mod)))
   }


   # Calculate percentile values using parametric (normal distn) method
   # Calls pcval_calc for actual calculations
   npcval <- function(d, y, adjcovMat, adjmodel) {
     # pcvals <- vector(length=length(d[d==1]))
      mod <- NULL

      # If adjusting for covariates, figure out stratified or linear
      if(!is.null(adjcovMat)) {
         pcvals <- vector(length=length(d))
         if(adjmodel=="linear") {
            # Assume normal distn for residuals, now including adjcov as
            # covariates in the model
            return(getLinearPcvals(d,y,adjcovMat,"normal"))
         } else if(adjmodel=="stratified") {
            stratas <- getStrata(d,y,adjcovMat)
            j <- 1
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
               currD <- currStrata[,1]
               currY <- currStrata[,2]
               resampIds <- as.numeric(rownames(currStrata))
               resampCases <- resampIds[which(currD==1)]
      #         pcvals[j:(j+length(currD[currD==1])-1)] <- npcval_calc(currD, currY)
               pcvals[resampCases] <- npcval_calc(currD, currY)
      #         j <- j + length(currD[currD==1])
            }
            pcvals <- pcvals[which(d==1)]
         }
      } else {
         # If not adjusting for covariates, the usual (entirely empirical) way
         pcvals <- npcval_calc(d,y)
      }

      return(list(pcvals, summary(mod)))
   }


   # Bootstrap CIs
   rocbsRreg <- function(i) {
      #Create CI matrix, with first col=SEs, second and third cols=CI
      nParam <- 2+length(regcov)+length(sregcov)
      names_sreg_temp <- sapply(sregcov, FUN=function(x) paste("s_",x,sep=""))
      paramNames <- c("alpha_0","alpha_1",regcov,names_sreg_temp)
      CImat <- matrix(nrow=nParam, ncol=3)
      set.seed(51)
      thetahat.star <- replicate(nsamp, do.oneRreg(i))
      alpha <- 1 - (level/100)
      CImat[,2:3] <- t(apply(thetahat.star, 1, 
                         function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
      CImat[,1] <- apply(thetahat.star, 1, function(z){sd(z)} )


      #alpha <- 1 - (level/100)
      #CImat[,2:3] <- t(apply(matrix(thetahat.star), 1, 
      #                       function(z){quantile(z, c(alpha/2, (1 - alpha/2)))}))
      #CImat[,1] <- apply(matrix(thetahat.star), 1, function(z){sd(z)} )
      
      V <- matrix(nrow=nParam,ncol=nParam,dimnames=list(paramNames, paramNames))
      for(i in 1:nParam) {
         for(j in i:nParam) {
            V[j,i] <- cov(thetahat.star[j,], thetahat.star[i,])
         }
      }

      if(bstrapRes) {
         # Write bootstrap results to file specified by resfile
         fileName <- ifelse(nmark==1, paste(resfile,".txt",sep=""), 
                            paste(resfile,i,".txt",sep=""))
         currFile <- file(fileName, open="w")
         cat(paste(paramNames, collapse=","), file=currFile, fill=T)
         apply( t(thetahat.star), 1, 
                function(x){cat(paste(x,collapse=","), file=currFile, append=T, fill=T)} )
         close(currFile)
      }
      return(list(CImat, V))
   }



   do.oneRreg <- function(i) {
      newAdjcovMat <- NULL
      regcovMat <- NULL
      sregcovMat <- NULL

      if(adjust & adjmodel=="stratified" & nostsamp==F) {
         stratas <- getStrata(d_vector,y[,i],adjcovMat)
         resample.ctrl <- NULL
         resample.case <- NULL
         resample.cohort <- NULL
         for(s in 1:length(stratas)) {
            resampIds <- as.numeric(rownames(stratas[[s]]))
            strataCluster <- clusterIDs[resampIds]
            resample <- getBstrapSample(stratas[[s]],noccsamp, cluster,
                           clusterUniqueMat, cListFull[[s]], strataCluster)
            if(!noccsamp) {
               resample.ctrl <- c(resample.ctrl, resampIds[resample[[1]]])
               resample.case <- c(resample.case, resampIds[resample[[2]]])
            } else {
               resample.cohort <- c(resample.cohort, resampIds[resample])
            }
         }
      } else {
         resample <- getBstrapSample(dataset_ordered,noccsamp, cluster,
                                     clusterUniqueMat, cListFull)
         if(!noccsamp) {
            resample.ctrl <- resample[[1]]
            resample.case <- resample[[2]]
         } else {
            resample.cohort <- resample
         }
      }

      #We have the resampled indices. Put together the new dataset
      if(!noccsamp) {
         newdata <- cbind( c(rep(0,length(resample.ctrl)),rep(1,length(resample.case))), 
            c(y[resample.ctrl,i],y[resample.case,i]) )
         
         colNums  <- which(colnames(dataset_ordered) %in% 
                           c(adjcov,regcov,sregcov))

         if(length(colNums) ==1) {
            newdata <- cbind(newdata,c(dataset_ordered[resample.ctrl,colNums],
                             dataset_ordered[resample.case,colNums]))
         } else if(length(colNums) > 1) {
            newdata <- cbind(newdata,rbind(
                             dataset_ordered[resample.ctrl,colNums],
                             dataset_ordered[resample.case,colNums]))
         }

         if(adjust) {
            if(length(adjcov) > 1) {
              newAdjcovMat <- as.data.frame(rbind(adjcovMat[resample.ctrl,], 
                                    adjcovMat[resample.case,]))
            } else {
              newAdjcovMat <- as.data.frame(c(adjcovMat[resample.ctrl,], 
                                    adjcovMat[resample.case,]))
            }
            colnames(newAdjcovMat) <- adjcov
         }

       #  if(!is.null(regcov)) {
       #     regcovMat <- cbind( regcovMat, c(dataset_ordered[resample.ctrl, 
       #        which(names(dataset_ordered)==regcov)], dataset_ordered[resample.case, 
       #        which(names(dataset_ordered)==regcov)]) )
       #     newdata <- cbind(newdata, regcovMat)
       #  }
       #  if(!is.null(sregcov)) {
       #     sregcovMat <- cbind( sregcovMat, c(dataset_ordered[resample.ctrl, 
       #        which(names(dataset_ordered)==sregcov)], dataset_ordered[resample.case, 
       #        which(names(dataset_ordered)==sregcov)]) )
       #     newdata <- cbind(newdata, sregcovMat)
       #  }
       #  if(adjust) {
       #     for(a in 1:length(adjcov)) {
       #        newAdjcovMat <- cbind(newAdjcovMat,c(adjcovMat[resample.ctrl,a], 
       #           adjcovMat[resample.case,a]))
       #     }
       #     newAdjcovMat <- as.data.frame(newAdjcovMat)
       #     colnames(newAdjcovMat) <- adjcov
       #     newdata <- cbind( newdata, newAdjcovMat )
       #  }
      } else {
         newdata <- cbind((dataset_ordered$d)[resample.cohort], 
                            y[resample.cohort,i] )
    #     if(!is.null(regcov)) {
    #        regcovMat <- cbind(regcovMat, dataset_ordered[resample.cohort, 
    #           which(names(dataset_ordered)==regcov)])
    #        newdata <- cbind(newdata, regcovMat)
    #     }
    #     if(!is.null(sregcov)) {
    #        sregcovMat <- cbind(sregcovMat, dataset_ordered[resample.cohort, 
    #           which(names(dataset_ordered)==sregcov)])
    #        newdata <- cbind(newdata, sregcovMat)
    #     }
    #     if(adjust) {
    #        for(a in 1:length(adjcov))
    #           newAdjcovMat <- cbind(newAdjcovMat,adjcovMat[resample.cohort,a])
    #        newAdjcovMat <- as.data.frame(newAdjcovMat)
    #        colnames(newAdjcovMat) <- adjcov
    #        newdata <- cbind( newdata, newAdjcovMat )
    #     }

         colNums  <- which(colnames(dataset_ordered) %in% 
                           c(adjcov,regcov,sregcov))

         if(length(colNums) >= 1) {
             newdata <- cbind(newdata,dataset_ordered[resample.cohort,colNums])
         }

         orderD <- order(newdata[,1])
         newdata <- newdata[orderD,]

         if(adjust) {
            newAdjcovMat <- as.data.frame(adjcovMat[resample.cohort,])
            newAdjcovMat <- as.data.frame(newAdjcovMat[orderD,])
            colnames(newAdjcovMat) <- adjcov
         }
      }

      newdata <- data.frame(newdata)

      if(length(colNums) == 0 ) {
         colnames(newdata) <- c(d, "y")
      } else {
         colnames(newdata) <- c(d, "y", colnames(dataset_ordered)[colNums])
      }

  #    if( adjust ) {
  #       colnames(newdata) <- c(d, "y", regcov, sregcov, adjcov)
  #    } else {
  #       colnames(newdata) <- c(d, "y", regcov, sregcov, NULL)
  #    }

      # Generate new percentile values
      if(pvcmeth=="empirical") {
         newPcvals <- (pcval(newdata[,1], newdata$y, newAdjcovMat, 
                             adjmodel, tiecorr))[[1]]
      } else {
         newPcvals <- (npcval(newdata[,1],newdata$y,newAdjcovMat, adjmodel))[[1]]
      }
      # Calculate regression coefficients based on new percentile values
      return(getbnparmReg(1-newPcvals, newdata, getModel=FALSE))
   }


   # Get parameter estimates for binormal ROC curve
   getbnparmReg <- function(in_plvals, in_dataset, getModel) {
#         bnmatr <- matrix(nrow=1, ncol=2+length(regcov)+length(sregcov))
 #        bnmatr <- vector( length=2+length(regcov)+length(sregcov) )

      k <- seq(length=np, from=1, to=np)
      f <- (a + (b-a)*k)/(np+1)
      if(link=="probit") {
         q <- qnorm(f)
      } else {
  #       q <- log(1-f) - log(f)
         q <- log(f) - log(1-f)
      }
      x <- rep(q, length(in_plvals))

      #cases <- subset(in_dataset, eval(parse(text=paste(d,"==1"))))
      eval(parse(text=paste("cases<-subset(in_dataset,",d,"==1)",sep="")))

      reg <- data.frame(x)
      names(reg) <- "x"
      #intercept covariates
      if(!is.null(regcov)) {
         for(r in 1:length(regcov))
            reg <- cbind(reg, rep(cases[,which(names(cases)==regcov[r])], 
                         each=length(f)) )
#           reg <- cbind(reg, rep(in_dataset[d==1,
#                        which(names(in_dataset)==regcov[r])], each=length(f)))
            names(reg) <- c("x",regcov)
      }

      #slope covariates
      if(!is.null(sregcov)) {
         for(s in 1:length(sregcov)) 
            reg <- cbind(reg, (rep(cases[,which(names(cases)==sregcov[s])], 
                         each=length(f)))*x )
#             reg <- cbind(reg, (rep(in_dataset[d==1,which(names(in_dataset)==sregcov[s])],
#                          each=length(f)))*x )
         names_reg_temp <- sapply(sregcov, FUN=function(x) paste("s_",x,sep=""))
         names(reg) <- c(names(reg)[1:(length(regcov)+1)],names_reg_temp)
      }

      expandedPlVals <- matrix( apply(matrix(in_plvals), 1, 
                                      function(x) {rep(x,np)}), 
                               nrow=np*(length(in_plvals)), ncol=1, byrow=T )
      expandedF <- rep(f, length(in_plvals))
      u <- matrix( as.numeric(expandedPlVals <= expandedF), 
                   nrow=np*length(in_plvals), ncol=1)

      formulaStr <- paste("u~",paste(names(reg),collapse="+"),sep="")
      if(link=="probit") {
         regrModel <- glm(as.formula(formulaStr), data=reg, 
                          family=binomial(probit))
      } else {
         regrModel <- glm(as.formula(formulaStr), data=reg, 
                          family=binomial(logit))
      }
      #bnmatr[1,1] <- regrModel$coeff[1]
      #bnmatr[1,2] <- regrModel$coeff[2]
      #bnmatr[1,3] <- regrModel$coeff[3]
      #bnmatr[1,4] <- regrModel$coeff[4]

      #bnmatr[1] <- regrModel$coeff[1]
	#bnmatr[2] <- regrModel$coeff[2]
	#bnmatr[3] <- regrModel$coeff[3]
	#bnmatr[4] <- regrModel$coeff[4]

      #return(bnmatr)
      if(getModel) {
         return(regrModel)
      }
      return(regrModel$coeff)
   }


   checkErrorsRocreg <- function() {
      if(length(unique(d_vector))!=2) cat("d must take on two values\n")
      else if(min(d_vector)!=0 | max(d_vector)!=1) cat("d must be 0/1\n")
      else if(is.null(y[,1])) cat(paste(markers[1],"must contain values\n"))
      else if(!(pvcmeth=="empirical"|pvcmeth=="normal"))
         cat("pvcmeth option must be either empirical or normal if specified\n")
      else if(!(link=="probit"|link=="logit"))
         cat("link option must be either probit or logit if specified\n")

      # Check sampling variability options
      else if(!is.numeric(nsamp) | (nsamp<1 & nsamp!=0))
         cat("nsamp argument must be >1\n")

      # Check interval() option arguments
      else if(!(interval[1]>=0 & interval[1]<=1 & interval[2]>=0 & interval[2]<=1))
         cat("first two interval arguments, a & b, must be between 0 & 1\n")
      else if(interval[2] <= interval[1]) cat("interval arguments must satisfy a < b\n")
      else if(!((interval[3]/as.integer(interval[3]))==1 & interval[3]>0))
         cat("3rd interval argument, np, must be a positive integer\n")

      # Check covariate adjustment options
      else if(!(adjmodel=="stratified"|adjmodel=="linear"))
         cat("adjmodel option must be either linear or stratified if specified\n")
      else if(!is.null(adjcov) & adjmodel=="stratified" & 
               isStrataCtrlLow(d_vector,adjcovMat,2)) 
         cat("fewer than 2 controls in some case-containing strata defined by 
             stratification variable adjcov.  
             Need to redefine/broaden adjustment strata specified by adjcov\n")

      # Not in Stata code. My own additions
      else if(!(ordinal==TRUE | ordinal==FALSE))
         cat("ordinal option must be TRUE or FALSE, if specified\n")
      else if(!(tiecorr==TRUE | tiecorr==FALSE))
         cat("tiecorr option must be TRUE or FALSE, if specified\n")
      else if(!(noccsamp==TRUE | noccsamp==FALSE))
         cat("noccsamp option must be TRUE or FALSE, if specified\n")
      else if(!(nostsamp==TRUE | nostsamp==FALSE))
         cat("nostsamp option must be TRUE or FALSE, if specified\n")
      else if(!(level>0 & level<100))
         cat("level option must be between 0 & 100, if specified\n")
      else if(!(replace==TRUE | replace==FALSE))
         cat("replace option must be TRUE or FALSE, if specified\n")
      else if(!(nobstrap==TRUE | nobstrap==FALSE))
         cat("nobstrap option must be TRUE or FALSE, if specified\n")

      else return(FALSE)
      return(TRUE)
   }

   ### END OF HELPER FUNCTIONS DEFINITIONS

   
   # Assign general variables
   nmark <- length(markers)
   if(link=="") link <- "probit"
   if(pvcmeth=="") pvcmeth <- "empirical"
   if(nsamp==0) nobstrap <- TRUE
   a <- interval[1]
   b <- interval[2]
   np <- interval[3] 
   adjust <- ifelse(!is.null(adjcov), TRUE, FALSE)
   nStrata <- 1


   #Do error checking and create working dataset
   #If dataset variable is specified
   if(!is.null(dataset)) {
      # Check that specified dataset is valid
      if(!exists(dataset))
         stop("Specified dataset does not exist\n")

      # Check that specified disease marker is valid
      if(!(d %in% names(eval(parse(text=dataset)))) )
         stop("Specified disease marker does not exist\n")

      # Check that specified marker vectors specified are valid
      if(sum(markers %in% names(eval(parse(text=dataset))))<length(markers) ) 
         stop("At least one of the specified test markers does not exist\n")

      # Disease and test markers exist - start creating working dataset
      working_dataset <- as.data.frame(eval(parse(text=paste(dataset,"$",d,sep=""))))
#      localMarkers <- NULL
      for(i in 1:nmark)
         working_dataset <- cbind(working_dataset, 
                               eval(parse(text=paste(dataset,"$",markers[i],sep=""))))
#       localMarkers <- c(localMarkers, paste("y",i,sep=""))
#       colnames(working_dataset) <- c((colnames(working_dataset))[-(i+1)], 
#                                      localMarkers[i])

      covNames = NULL

      # Check that specified adjcov markers specified are valid. 
      #    If so, add to working dataset.
      if(!is.null(adjcov)) {
         if(sum(adjcov %in% names(eval(parse(text=dataset))))<length(adjcov) ) 
            stop("At least one of the specified adjcov markers does not exist\n")
         else {
            covNames = c(covNames,adjcov)
            for(i in 1:length(adjcov))
               working_dataset <- cbind(working_dataset, 
                                 eval(parse(text=paste(dataset,"$",adjcov[i],sep=""))))
         }
      }
      # Check that specified cluster variables are valid. 
      #     If so, add to working dataset (after checking we haven't already 
      #     done so).
      if(!is.null(cluster)) {
         if(sum(cluster %in% names(eval(parse(text=dataset))))<length(cluster) ) 
            stop("At least one of the specified cluster variables does not exist\n")
         else {
            for(i in 1:length(cluster))
               if(!(cluster[i] %in% covNames)) {
                  covNames = c(covNames,cluster[i])
                  working_dataset <- cbind(working_dataset, 
                       eval(parse(text=paste(dataset,"$",cluster[i],sep=""))))
               }
         }
      }
      # Check that specified regcov variables are valid. 
      #     If so, add to working dataset (after checking we haven't already 
      #     done so).
      if(!is.null(regcov)) {
         if(sum(regcov %in% names(eval(parse(text=dataset))))<length(cluster) ) 
            stop("At least one of the specified regcov variables does not exist\n")
         else {
            for(i in 1:length(regcov))
               if(!(regcov[i] %in% covNames)) {
                  covNames = c(covNames,regcov[i])
                  working_dataset <- cbind(working_dataset, 
                       eval(parse(text=paste(dataset,"$",regcov[i],sep=""))))
               }
         }
      }
      # Check that specified sregcov variables are valid. 
      #     If so, add to working dataset (after checking we haven't already 
      #     done so).
      if(!is.null(sregcov)) {
         if(sum(sregcov %in% names(eval(parse(text=dataset))))<length(cluster) ) 
            stop("At least one of the specified sregcov variables does not exist\n")
         else {
            for(i in 1:length(sregcov))
               if(!(sregcov[i] %in% covNames)) {
                  covNames = c(covNames,sregcov[i])
                  working_dataset <- cbind(working_dataset, 
                       eval(parse(text=paste(dataset,"$",sregcov[i],sep=""))))
               }
         }
      }
      colnames(working_dataset) <- c(d,markers,covNames)
   } else {  #If dataset variable is not specified
      working_dataset_colnames <- NULL
      # Check that specified disease marker is valid
      splitVar <- strsplit(d,"$",fixed=TRUE)
      if(length(splitVar[[1]]) == 1) {
         if(!exists(d))
            stop("Specified disease marker does not exist\n")
         working_dataset_colnames <- d
         working_dataset <- as.data.frame(eval(parse(text=d)))
      }
      else {
         if(!((splitVar[[1]])[2] %in% names(eval(parse(text=(splitVar[[1]])[1])))) )
            stop("Specified disease marker does not exist\n")
         working_dataset_colnames <- (splitVar[[1]])[2]
         working_dataset <- as.data.frame(eval(parse(text=d)))
         d <- (splitVar[[1]])[2]
      } 

      # Check that specified marker vectors specified are valid
      splitVar <- strsplit(markers,"$",fixed=TRUE)
      for(i in 1:length(markers)) {
         if(length(splitVar[[i]]) == 1) {
            if(!exists(markers[i]))
               stop("At least one of the specified test markers does not exist\n")
            working_dataset_colnames <- c(working_dataset_colnames, markers[i])
            working_dataset <- cbind(working_dataset, 
                                     eval(parse(text=paste(markers[i],sep=""))))
         } else {
            if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
               stop("At least one of the specified test markers does not exist\n")
            working_dataset_colnames <- c(working_dataset_colnames, 
                                          (splitVar[[i]])[2] )
            working_dataset <- cbind(working_dataset, 
                                     eval(parse(text=paste(markers[i],sep=""))))
            markers[i] <- (splitVar[[i]])[2]
         }
      }

      # Check that specified adjcov markers specified are valid
      if(!is.null(adjcov)) {
         splitVar <- strsplit(adjcov,"$",fixed=TRUE)
         for(i in 1:length(adjcov)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(adjcov[i]))
                  stop("At least one of the specified adjcov variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, adjcov[i])
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(adjcov[i],sep=""))))
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified adjcov variables does not exist\n")
               working_dataset_colnames <- c( working_dataset_colnames, 
                                              (splitVar[[i]])[2] )
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(adjcov[i],sep=""))))
               adjcov[i] <- (splitVar[[i]])[2]
            } 
         }
      }
      # Check that specified regcov markers specified are valid
      if(!is.null(regcov)) {
         splitVar <- strsplit(regcov,"$",fixed=TRUE)
         for(i in 1:length(regcov)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(regcov[i]))
                  stop("At least one of the specified regcov variables does not exist\n")
               if(! regcov[i] %in% working_dataset_colnames) {
                  working_dataset_colnames <- c(working_dataset_colnames, regcov[i])
                  working_dataset <- cbind(working_dataset, 
                                           eval(parse(text=paste(regcov[i],sep=""))))
               }
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified regcov variables does not exist\n")
               if(! (splitVar[[i]])[2] %in% working_dataset_colnames) {
                  working_dataset_colnames <- c( working_dataset_colnames, 
                                                (splitVar[[i]])[2] )
                  working_dataset <- cbind(working_dataset, 
                                           eval(parse(text=paste(regcov[i],sep=""))))
               }
               regcov[i] <- (splitVar[[i]])[2]
            } 
         }
      }
      # Check that specified sregcov markers specified are valid
      if(!is.null(sregcov)) {
         splitVar <- strsplit(sregcov,"$",fixed=TRUE)
         for(i in 1:length(sregcov)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(sregcov[i]))
                  stop("At least one of the specified sregcov variables does not exist\n")
               if(! sregcov[i] %in% working_dataset_colnames) {
                  working_dataset_colnames <- c(working_dataset_colnames, sregcov[i])
                  working_dataset <- cbind(working_dataset, 
                                           eval(parse(text=paste(sregcov[i],sep=""))))
               }
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified sregcov variables does not exist\n")
               if(! (splitVar[[i]])[2] %in% working_dataset_colnames) {
                  working_dataset_colnames <- c( working_dataset_colnames, 
                                                (splitVar[[i]])[2] )
                  working_dataset <- cbind(working_dataset, 
                                           eval(parse(text=paste(sregcov[i],sep=""))))
               }
               sregcov[i] <- (splitVar[[i]])[2]
            } 
         }
      }
      # Check that specified cluster variables are valid
      if(!is.null(cluster)) {
         splitVar <- strsplit(cluster,"$",fixed=TRUE)
         for(i in 1:length(cluster)) {
            if(length(splitVar[[i]]) == 1) {
               if(!exists(cluster[i]))
                  stop("At least one of the specified cluster variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, cluster[i])
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(cluster[i],sep=""))))
            }
            else {
               if(!((splitVar[[i]])[2] %in% names(eval(parse(text=(splitVar[[i]])[1])))) )
                  stop("At least one of the specified cluster variables does not exist\n")
               working_dataset_colnames <- c(working_dataset_colnames, 
                                             (splitVar[[i]])[2])
               working_dataset <- cbind(working_dataset, 
                                        eval(parse(text=paste(cluster[i],sep=""))))
               cluster[i] <- (splitVar[[i]])[2]
            }
         }
      }
      colnames(working_dataset) <- working_dataset_colnames
#      markers <- working_dataset_colnames[2:(1+length(markers))]
#      adjcov <- working_dataset_colnames[(1+length(markers)+1):(1+length(markers)+1+length(adjcov))]
#      cluster <- working_dataset_colnames[(1+length(markers)+1+length(adjcov)+1):
#         (1+length(markers)+1+length(adjcov)+1+length(cluster))] 
   }

   #Order dataset by disease status, to give final working dataset
   dataset_ordered <- working_dataset[order(
                       eval(parse(text=paste("working_dataset$",d,sep="")))),]


   #### First round of error checking done. Working dataset created.
#   # Create data vectors, d_vector and y
#   if(is.null(dataset)) {
#      working_dataset <- as.data.frame(eval(parse(text=d)))
#      colnames(working_dataset) <- "d"
#      localMarkers <- NULL
#      for(i in 1:nmark) {
#         working_dataset <- cbind(working_dataset, 
#                                  eval(parse(text=paste(markers[i],sep=""))))
#         localMarkers <- c(localMarkers, paste("y",i,sep=""))
#         colnames(working_dataset) <- c((colnames(working_dataset))[-(i+1)], 
#                                        localMarkers[i])
#      }
#      dataset_ordered <- working_dataset[order(eval(parse(text="working_dataset$d"))),]
#   }
#   else {
#      dataset_ordered <- eval(as.symbol(dataset))[order(eval(parse(text=paste(dataset,
#         "$",d,sep="")))),]
#      localMarkers <- markers
#   }

   missingDataRows <- (which(is.na(dataset_ordered), arr.ind=TRUE))[,1]
   if(length(missingDataRows)>0) 
      dataset_ordered <- dataset_ordered[-missingDataRows,]

##### Fix after checking what dataset_ordered column names are
#   if(is.null(dataset))
#      d_vector <- eval(parse(text=paste("dataset_ordered$","d",sep="")))
#   else
      d_vector <- eval(parse(text=paste("dataset_ordered$",d,sep="")))

   y <- matrix(nrow=(dim(dataset_ordered))[1], ncol=nmark)
   for(i in 1:nmark)
      y[,i] <- eval(parse(text=paste("dataset_ordered","$",markers[i],sep="")))
#      y[,i] <- eval(parse(text=paste("dataset_ordered","$",localMarkers[i],sep="")))




   adjcovMat <- NULL
   if(adjust) {
      adjcovMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(adjcov))
      for(i in 1:length(adjcov))
         adjcovMat[,i] <- eval(parse(text=
                               paste("dataset_ordered","$",adjcov[i],sep="")))
      adjcovMat <- data.frame(adjcovMat)
      colnames(adjcovMat) <- adjcov
   }


   clusterMat <- NULL
   clusterUniqueMat <- NULL
   clusterIDs <- vector(length=(dim(dataset_ordered)[1]))
   if(!is.null(cluster)) {
      clusterMat <- matrix(nrow=(dim(dataset_ordered))[1], ncol=length(cluster))
      for(i in 1:length(cluster))
         clusterMat[,i] <- eval(parse(text=
                              paste("dataset_ordered","$",cluster[i],sep="")))
      clusterMat <- data.frame(clusterMat)
      colnames(clusterMat) <- cluster
      clusterUniqueMat <- unique(as.data.frame(cbind(d_vector,clusterMat)))
      colnames(clusterUniqueMat) <- c(d,cluster)
      for(s in 1:(dim(clusterUniqueMat)[1])) {
         currCluster <- as.data.frame(cbind(d_vector, clusterMat, 
                                      seq(1:(dim(dataset_ordered)[1]))))
         colnames(currCluster) <- c(d,cluster,"origDatasetID")
##         currCluster <- as.data.frame(cbind(dataset_ordered,
##                                      seq(1:(dim(dataset_ordered)[1]))))
##         colnames(currCluster) <- c(names(dataset_ordered),"origDatasetID")
         for(k in 1:length(cluster)) {
            currCluster <- currCluster[which(as.numeric(eval(parse(
                            text=paste("currCluster$",cluster[k],sep="")))) == 
                            clusterUniqueMat[s,k+1]),]
         }
         currCluster <- currCluster[which(
                    eval(parse(text=paste("currCluster$",d,sep=""))) == 
                    eval(parse(text=paste("clusterUniqueMat$",d,sep="")))[s]),]
         clusterIDs[currCluster$origDatasetID] <- s
      }
   }

   # calculate cluster lists
   if(!is.null(cluster)) { 
      if(adjust & adjmodel=="stratified" & nostsamp==FALSE) {
         cListFull <- list()
         stratas <- getStrata(d_vector,y[,i],adjcovMat)
         for(s in 1:length(stratas)) {
            resampIds <- as.numeric(rownames(stratas[[s]]))
            cListFull[[s]] <- makeClist(clusterIDs[resampIds])
         }
      } else {
         cListFull <- makeClist(clusterIDs)
      }
   }

   # Proceed if no errors
   isError <- checkErrorsRocreg()

   if(!isError) {
   
      if(adjmodel=="stratified" & isStrataCtrlLow(d_vector,adjcovMat,10)) {
         cat("Warning: fewer than 10 controls in some case-containing strata defined by 
            stratification variable adjcov\n")
      }

      bstrapRes <- FALSE
     # bstrapResMat <- NULL
     # bstrapResMatNames <- NULL
      # Create file to store bootstrap results
      if(!nobstrap) {
         if(!is.null(resfile)) {
            if(nmark==1)
               fileExists <- file.exists(paste(resfile,".txt",sep=""))
            else {
               fileExists <- 0
               for(i in 1:nmark)
                  fileExists <- fileExists + file.exists(paste(resfile,i,".txt",sep=""))
            }
            if(!fileExists || (fileExists>0 && replace==TRUE) ) {
               #bstrapRes <- file(paste(resfile,".txt",sep=""), open="w")  # open an output file connection
               bstrapRes <- TRUE
            } else {
               stop("file specified by resfile already exists, ",
                    "use 'replace' option to replace existing file\n\n")
            }
         }
      }

      # Generate percentile values
      pcvalResults <- vector("list",length=2)
      pcvals <- matrix(nrow=nmark, ncol=length(d_vector[d_vector==1]), byrow=T)
      # if(adjust & adjmodel=="linear")
      linModels <- vector("list",length=nmark)

      if(pvcmeth=="empirical") {
         for(i in 1:nmark) {
            pcvalResults <- pcval(d=d_vector, y=y[,i], adjcovMat, adjmodel, tiecorr) 
            pcvals[i,] <- pcvalResults[[1]]
            linModels[[i]] <- pcvalResults[[2]]
         }
      } else {
         for(i in 1:nmark) {
            pcvalResults <- npcval(d=d_vector, y=y[,i], adjcovMat, adjmodel)
            pcvals[i,] <- pcvalResults[[1]]
            linModels[[i]] <- pcvalResults[[2]]
         }
      }


      # Generate placement values
      plvals <- 1-pcvals


      # Output specified options
      outOpts_rocparam <- NULL
      outOpts_pvcmeth <- NULL
      outOpts_boot <- NULL
      output <- NULL


      cat( paste("ROC regression for markers:", paste(markers, collapse=", "), "\n"))
      if(!is.null(regcov))
         cat( paste("Model intercept term covariates:", paste(regcov, collapse=", "), "\n"))
      if(!is.null(sregcov))
         cat( paste("Model slope term covariates:", paste(sregcov, collapse=", "), "\n"))


      outOpts_pvcmeth <- rbind(outOpts_pvcmeth, pvcmeth)
      if(pvcmeth=="empirical") {
         outOpts_pvcmeth <- rbind(outOpts_pvcmeth, ifelse(tiecorr==FALSE, "no", "yes"))
         rownames(outOpts_pvcmeth) <- c("method:", "tie correction:")
      } else {
         rownames(outOpts_pvcmeth) <- "method:"
      }
      colnames(outOpts_pvcmeth) <- ""
      cat("\nPercentile value calculation")
      print(outOpts_pvcmeth, quote=F)


      if(adjust) {
         outOpts_covAdj <- ifelse(adjmodel=="stratified", "stratified", "linear model")
         outOpts_covAdj <- rbind(outOpts_covAdj, paste(adjcov, collapse=", "))
         rownames(outOpts_covAdj) <- c("method:", "covariates:")
         colnames(outOpts_covAdj) <- ""
         cat("\nCovariate adjustment")
         print(outOpts_covAdj, quote=F)

         if(adjmodel=="stratified") {
            stratas <- getStrata(d_vector,y[,1],adjcovMat)

            dCount <- matrix(nrow=length(stratas),ncol=2)
            for(s in 1:length(stratas)) {
               currStrata <- stratas[[s]]
           #    dCount[s,1] <- eval(parse(text=
           #             paste("dim(subset(currStrata,",d,"==0))[1]",sep="")))
           #    dCount[s,2] <- eval(parse(text=
           #             paste("dim(subset(currStrata,",d,"==1))[1]",sep="")))
               dCount[s,1] <- length(which(currStrata[,1]==0))
               dCount[s,2] <- length(which(currStrata[,1]==1))		
            }
            nStrata <- length(stratas)
            dCount <- cbind(seq(1:length(stratas)), dCount, dCount[,1]+dCount[,2])
            colnames(dCount) <- c("Stratum",paste(d,"=0",sep=""),
                                  paste(d,"=1",sep=""),"Total")
            rownames(dCount) <- rep("",dim(dCount)[1])
            dCount <- rbind(dCount, c("Total", sum(dCount[,2]),sum(dCount[,3]),
                                      sum(dCount[,4])))
            cat(paste("# of case-containing strata:",length(stratas),"\n\n"))
            print(dCount, quote=F)
         }
      }


      outOpts_rocparam <- rbind(outOpts_rocparam, ifelse(link=="probit", 
         "probit - binormal ROC", "logit - bilogistic ROC"))
      outOpts_rocparam <- rbind(outOpts_rocparam, np)
      outOpts_rocparam <- rbind(outOpts_rocparam, paste("(", a, ",", b, ")", sep=""))
      rownames(outOpts_rocparam) <- c("link function:", "number of points:", 
                                       "on FPR interval:")
      colnames(outOpts_rocparam) <- ""
      cat("\nGLM fit")
      print(outOpts_rocparam, quote=F)

      if(!nobstrap) {
         #Sampling options
         cat("\n model coefficient bootstrap se's and CI's based on sampling\n")
         sampDesign <- ifelse(noccsamp==FALSE, " separately from cases and controls\n", 
            " w/o respect to case/control status\n")
         cat(sampDesign)
         if(adjust & adjmodel=="stratified")
            cat(" and from within covariate strata\n")

         cat( paste("\nbootstrap samples:",nsamp,"\n") )

#         outOpts_boot <- rbind(outOpts_boot, nStrata, length(d_vector), nsamp)
#         rownames(outOpts_boot) <- c("Number of strata","Number of obs","Replications")
#         colnames(outOpts_boot) <- rep("",dim(outOpts_boot)[2])
      } else {
         cat("\n no bootstrap sampling specified.\n")
         cat(" bootstrap-based se's and CI's for model coefficients",
             "will not be calculated.")
      }
      
      regCoeffNames <- c("alpha_0","alpha_1")
      if(!is.null(regcov)) regCoeffNames <- c(regCoeffNames,regcov)
      if(!is.null(sregcov)) regCoeffNames <- c(regCoeffNames, sapply(sregcov, 
         FUN=function(x) paste("s_",x,sep="")))
      GLMparm <- matrix(nrow=nmark,ncol=length(regCoeffNames))
      rownames(GLMparm) <- markers
      colnames(GLMparm) <- regCoeffNames
      
      #CImat <- matrix(nrow=length(regCoeffNames), ncol=3, byrow=T)
      V <- matrix(nrow=length(regCoeffNames), ncol=length(regCoeffNames))
      
      resultList <- vector("list")
     
      for(i in 1:nmark) {
         cat("\n\n******************************\n")
         cat( paste("Model results for marker:",markers[i],"\n\n") )
         
         if(adjust & adjmodel=="linear") {
            cat("   Covariate adjustment - linear model, controls only\n")
            print(linModels[[i]])
            cat("\n\n************\n\n")
         }
         cat("   ROC-GLM model\n\n")
         
         currModel <- getbnparmReg(1-pcvals[i,],dataset_ordered, getModel=TRUE)
         GLMparm[i,] <- signif(currModel$coeff, 3)

         #GLMparm[i,] <- signif(getbnparmReg(1-pcvals[i,],dataset_ordered), 3)
         #GLMparm[i,] <- b <- signif(getbnparmReg(1-pcvals[i,],dataset_ordered), 3)
         #b <- signif(getbnparmReg(1-pcvals[i,],dataset_ordered), 3)
         #estimates <- signif(getbnparmReg(1-pcvals[i,],dataset_ordered), 3)

         #currList <- list(b,V,GLMparm)
         #names(currList) <- c("b","V","GLMparm")
         #eval(parse(text=paste("results$rocreg_m",i,"<-currList",sep="")))

         #output <- cbind(matrix(regCoeffNames,ncol=1,byrow=F), 
         #matrix(b,ncol=1,byrow=F))
         #output <- cbind(matrix(regCoeffNames,ncol=1,byrow=F), 
         #                matrix(estimates,ncol=1,byrow=F))
         output <- cbind(matrix(regCoeffNames,ncol=1,byrow=F), 
                         matrix(GLMparm[i,],ncol=1,byrow=F))

         if(!nobstrap) {
            cat("Bootstrap results\n")
            cat( paste( "Number of strata = ", nStrata, "\t\t\tNumber of obs\t= ",
               (dim(dataset_ordered))[1], "\n" ) )
            cat( paste( "\t\t\t\t\tReplications\t= ", nsamp, "\n\n" ) )
            #print(outOpts_boot, quote=F)


            bstrapResults <- rocbsRreg(i=i)
            output <- cbind( output, signif((bstrapResults)[[1]],3) )
            colnames(output) <- c("", "Observed Coef.", "Bootstrap Std. Err.", 
                                  paste("[", level,"% Conf.",sep=""), 
                                  paste("Interval", "]", sep=""))
            rownames(output) <- rep("",length(regCoeffNames))

            #currList <- list(b,V)
            #currList <- list(estimates,V)
            #names(currList) <- c("b","V")
            #diag(V) <- as.numeric(output[,3])^2
            currList <- list(currModel,bstrapResults[[2]])
            names(currList) <- c("fit","V")
            
         } else {
            #currList <- list(b)
            #currList <- list(estimates)
            #names(currList) <- c("b")
            currList <- list(currModel)
            names(currList) <- c("fit")
            colnames(output) <- c("Model term", "Coefficient")
            rownames(output) <- rep("",length(regCoeffNames))
         }
         eval(parse(text=paste("resultList$rocreg_m",i,"<-currList",sep="")))
#         eval(parse(text=paste("resultList$rocreg_m",i,"<-currModel",sep="")))
         #print(format(output, justify="left"), quote=F)
         print(output, quote=F)
      }

      resultList$GLMparm <- GLMparm
      invisible(resultList)
         
   }
}




//////////////////////////
///// Stata commands /////
//////////////////////////

//Page 2
use http://labs.fhcrc.org/pepe/book/data/wiedat2b
roccurve d y1 y2, roc(.2) level(90)

//Page 5
use http://labs.fhcrc.org/pepe/book/data/wiedat2b
roccurve d y2, pvcmeth(empirical) rocmeth(nonparametric)
roccurve d y2, pvcmeth(empirical) rocmeth(parametric) link(probit)
roccurve d y2, pvcmeth(normal) rocmeth(nonparametric)
roccurve d y2, pvcmeth(normal) rocmeth(parametric)

//Page 13
set seed 8378923
comproc d y1 y2, auc roc(0.2)


######################
##### R commands #####
######################


setwd("/Users/darylm/Desktop/pcvsuite")
#source("roccurve.r")
#source("comproc.r")

#Page 2
#panCan <- read.csv("http://labs.fhcrc.org/pepe/book/data/wiedat2b.csv", header = TRUE, sep = ",")
panCan <- read.csv("wiedat2b.csv", header = TRUE, sep = ",")

roccurve(dataset="panCan", d="d", markers=c("y1","y2"), roc=.2, level=90)
roccurve(d="panCan$d", markers=c("panCan$y1","panCan$y2"), roc=.2, level=90)

#Page 5
panCan <- read.csv("http://labs.fhcrc.org/pepe/book/data/wiedat2b.csv", header = TRUE, sep = ",")
roccurve(dataset="panCan", d="d", markers="y2", pvcmeth="empirical", rocmeth="nonparametric")
roccurve(dataset="panCan", d="d", markers="y2", pvcmeth="empirical", rocmeth="parametric", link="probit")
roccurve(dataset="panCan", d="d", markers="y2", pvcmeth="normal", rocmeth="nonparametric")
roccurve(dataset="panCan", d="d", markers="y2", pvcmeth="normal", rocmeth="parametric")

#Page 13
comproc(dataset="panCan", d="d", markers=c("y1","y2"), auc=T, roc=.2)


#######################
##### 2nd article #####
#######################
audio = read.csv("nnhs2.csv")
roccurve(dataset="audio", d="d", markers=c("y1","y2","y3"), roc=.2, level=90)

quartz(height=4,width=8)
par(mfrow=c(1,2))
roccurve(dataset="audio", d="d", markers=c("y1","y2","y3"), roc=.2, nobstrap=TRUE)
#quartz(height=4,width=4)
roccurve(dataset="audio", d="d", markers=c("y1","y2","y3"), 
          adjcov="gender", adjmodel="stratified", roc=.2, nobstrap=TRUE)
quartz(height=4,width=4)
xx <- roccurve(dataset="audio", d="d", markers=c("y1","y2","y3"), 
         adjcov=c("gender","currage"), adjmodel="linear", 
	 roc=.2) #, nobstrap=TRUE)

xx <- roccurve(dataset="audio", d="d", markers=c("y1","y2","y3"), 
         adjcov=c("gender","currage"), adjmodel="linear", 
	 pvcmeth="normal",rocmeth="parametric", nobstrap=TRUE)     


	  
	  
function(dataset=NULL, d, markers, rocmeth="nonparametric", link="probit", 
   interval=c(0, 1, 10), ordinal=FALSE, c_fpr=NULL, c_tpr=NULL,
   nograph=FALSE, bw=FALSE, roc=NULL, rocinv=NULL, offset=0.006,
   pvcmeth="empirical", tiecorr=FALSE, adjcov=NULL, adjmodel="stratified",
   nsamp=1000, noccsamp=FALSE, nostsamp=FALSE, cluster=NULL, bsparam=TRUE, level=95,
   genrocvars=FALSE, genpcv=FALSE, replace=FALSE, nobstrap=FALSE) {
   
   
	  